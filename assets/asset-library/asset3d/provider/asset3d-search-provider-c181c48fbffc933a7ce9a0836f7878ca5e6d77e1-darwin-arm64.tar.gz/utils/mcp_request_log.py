"""
MCP Request Logging Module

Logs MCP requests to daily log files for monitoring and debugging.
Only writes when MCP_LOG_DIR environment variable is set (e.g., /log in Docker).
Log format: JSON lines, one per request.
"""

import json
import os
import time
from datetime import date
from pathlib import Path
from typing import Any, Optional, Union


def _get_log_dir() -> str:
    """Get log directory from environment."""
    return os.environ.get("MCP_LOG_DIR", "")


def _daily_log_path() -> Path:
    """Get today's log file path."""
    log_dir = _get_log_dir()
    today = date.today().isoformat()
    return Path(log_dir) / f"mcp-requests-{today}.log"


def append_mcp_request_log(
    service: str,
    method: str,
    tool: Optional[str] = None,
    duration_ms: float = 0.0,
    status: Union[int, str] = "",
    error: Optional[str] = None,
    call_id: Optional[str] = None,
    arguments: Optional[Any] = None,
    result_text: Optional[str] = None,
) -> None:
    """
    Append an MCP request log entry.

    Silently skips if MCP_LOG_DIR is not set.

    Args:
        service: Service name (e.g., "gemini-image", "prompt-optimization")
        method: HTTP method or MCP method name
        tool: Tool name if applicable
        duration_ms: Request duration in milliseconds
        status: HTTP status code or status string
        error: Error message if any
    """
    log_dir = _get_log_dir()
    if not log_dir:
        return

    try:
        log_path = _daily_log_path()
        log_path.parent.mkdir(parents=True, exist_ok=True)

        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
            "service": service,
            "method": method,
            "tool": tool or "",
            "duration_ms": round(duration_ms, 2),
            "status": status,
        }

        if error:
            entry["error"] = error
        if call_id:
            entry["call_id"] = call_id
        if arguments is not None:
            entry["arguments"] = arguments
        if result_text:
            entry["result_text"] = result_text

        line = json.dumps(entry, ensure_ascii=False) + "\n"

        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        # Silently ignore logging failures - don't affect request processing
        pass
