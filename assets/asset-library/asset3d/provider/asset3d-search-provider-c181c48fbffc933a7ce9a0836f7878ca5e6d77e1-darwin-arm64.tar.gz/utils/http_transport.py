"""
HTTP Transport Module for MCP Servers

Provides a unified way to run MCP servers in HTTP mode using:
- Starlette for ASGI app
- uvicorn for serving
- StreamableHTTPSessionManager for MCP protocol

Usage:
    from mcp.server import Server
    from utils import run_http_server

    server = Server("my-service")
    # ... register tools ...

    if os.environ.get("MCP_TRANSPORT") == "http":
        run_http_server(server, port=3100, service_name="my-service")
"""

import contextlib
import contextvars
import os
import time
from collections.abc import AsyncIterator
from typing import Any, Optional, Dict

from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Mount
from starlette.types import Receive, Scope, Send

import uvicorn

from mcp.server import Server
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

from .mcp_request_log import append_mcp_request_log


# ── Per-request config from the profile (国内/海外 + provider/model + …) ──────
# The agent (agentic_os MCP client) forwards profile-configured headers to each
# MCP server on every request — see infrastructure/mcp/client.ts requestInit
# headers (it already sends X-AW-DEVICETYPE the same way). The marketplace
# profile (workbench_cn vs workbench_oversea — already the region intent) sets
# `mcpServers.<svc>.headers: { X-AW-Region: cn|oversea, X-AW-Model-Provider: …,
# X-AW-Image-Provider: … }`. So config follows the profile, not a per-call arg.
#
# We capture all inbound `x-aw-*` headers into a ContextVar set at the top of
# `mcp_route` (per ASGI request) — verified safe under
# StreamableHTTPSessionManager `stateless=True`: each POST gets a fresh
# transport, and anyio `tg.start()` copies the request task's context into the
# spawned tool-handler task, so concurrent requests never cross-talk.
#
# Extend by reading new headers via `get_request_config().get("X-AW-Foo")`, or
# add a typed accessor on RequestConfig below.
_CONFIG_CTX: "contextvars.ContextVar[Optional[Dict[str, str]]]" = contextvars.ContextVar(
    "aw_request_config", default=None
)

# Header values (case-insensitive) that mean "overseas".
_OVERSEA_VALUES = frozenset({"oversea", "overseas", "intl", "global", "na", "en"})


class RequestConfig:
    """Typed view over the inbound `x-aw-*` headers for the current request.

    Per-key fallback order is: inbound header > env > default. Header lookups are
    case-insensitive and accept either the full `X-AW-Foo` name or the bare
    `Foo` suffix.
    """

    __slots__ = ("_headers",)

    def __init__(self, headers: Optional[Dict[str, str]]):
        self._headers = headers or {}

    def get(self, name: str, default: Optional[str] = None) -> Optional[str]:
        key = name.strip().lower()
        if not key.startswith("x-aw-"):
            key = "x-aw-" + key
        val = self._headers.get(key)
        return val if (val is not None and val != "") else default

    def region(self) -> str:
        raw = self.get("x-aw-region") or os.environ.get("AW_REGION") or "cn"
        return raw.strip().lower()

    def is_oversea(self) -> bool:
        return self.region() in _OVERSEA_VALUES

    def model_provider(self, default: Optional[str] = None) -> Optional[str]:
        return self.get("x-aw-model-provider") or os.environ.get("MODEL_PROVIDER") or default

    def image_provider(self, default: Optional[str] = None) -> Optional[str]:
        return self.get("x-aw-image-provider") or os.environ.get("DEFAULT_IMAGE_PROVIDER") or default


def get_request_config() -> RequestConfig:
    """RequestConfig for the current request (empty/env-backed outside HTTP mode)."""
    return RequestConfig(_CONFIG_CTX.get())


def get_region() -> str:
    """Resolved region: inbound `X-AW-Region` > `AW_REGION` env > `"cn"`. Lowercased."""
    return get_request_config().region()


def is_oversea() -> bool:
    """True when the current request resolves to an overseas region."""
    return get_request_config().is_oversea()


def _capture_request_config(scope: Scope) -> None:
    """Snapshot all inbound `x-aw-*` headers into the per-request contextvar.
    Always sets (even when none present) so a fresh request never reads stale state."""
    cfg: Dict[str, str] = {}
    for key, val in scope.get("headers") or []:
        try:
            name = key.decode("latin-1").lower()
        except Exception:
            continue
        if name.startswith("x-aw-"):
            cfg[name] = val.decode("latin-1").strip()
    _CONFIG_CTX.set(cfg)


def run_http_server(
    server: Server,
    port: int,
    service_name: str,
    host: str = "0.0.0.0",
    health_extra: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Run an MCP server in HTTP mode.

    This function blocks and runs the HTTP server using uvicorn.

    Args:
        server: MCP Server instance with tools registered
        port: Port to listen on
        service_name: Service name for logs and /health endpoint
        host: Host to bind (default 0.0.0.0 for Docker)
        health_extra: Extra fields to include in /health response
    """
    health_extra = health_extra or {}

    session_manager = StreamableHTTPSessionManager(
        app=server,
        event_store=None,
        json_response=True,
        stateless=True,
    )

    async def handle_streamable_http(scope: Scope, receive: Receive, send: Send) -> None:
        await session_manager.handle_request(scope, receive, send)

    async def mcp_route(scope: Scope, receive: Receive, send: Send) -> None:
        # Capture per-request profile config BEFORE handing off to the SDK
        # session manager — the tool handler runs in a task that copies this context.
        _capture_request_config(scope)
        method = scope.get("method", "")

        if method == "POST":
            start = time.perf_counter()
            status_holder = [None]

            async def wrapped_send(msg):
                if isinstance(msg, dict) and msg.get("type") == "http.response.start":
                    status_holder[0] = msg.get("status", "")
                await send(msg)

            await handle_streamable_http(scope, receive, wrapped_send)

            duration_ms = (time.perf_counter() - start) * 1000
            append_mcp_request_log(
                service=service_name,
                method="POST",
                tool="",
                duration_ms=duration_ms,
                status=status_holder[0] or "",
            )
        elif method == "GET":
            response = JSONResponse(
                {"error": "Method not allowed. Use POST for stateless MCP requests."},
                status_code=405,
            )
            await response(scope, receive, send)
        else:
            response = JSONResponse(
                {"error": "Method not allowed. Stateless server does not support session termination."},
                status_code=405,
            )
            await response(scope, receive, send)

    @contextlib.asynccontextmanager
    async def lifespan(app: Starlette) -> AsyncIterator[None]:
        async with session_manager.run():
            yield

    async def asgi_app(scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            return

        path = scope.get("path", "").rstrip("/") or "/"
        method = scope.get("method", "")

        if path == "/health" and method == "GET":
            response = JSONResponse({
                "status": "ok",
                "service": service_name,
                **health_extra,
            })
            await response(scope, receive, send)
            return

        if path == "/mcp":
            await mcp_route(scope, receive, send)
            return

        response = JSONResponse({"error": "Not found"}, status_code=404)
        await response(scope, receive, send)

    starlette_app = Starlette(
        routes=[Mount("/", app=asgi_app)],
        lifespan=lifespan,
    )

    print(f"[{service_name}] MCP HTTP Server listening on http://{host}:{port}/mcp", flush=True)
    uvicorn.run(starlette_app, host=host, port=port, log_level="info")
