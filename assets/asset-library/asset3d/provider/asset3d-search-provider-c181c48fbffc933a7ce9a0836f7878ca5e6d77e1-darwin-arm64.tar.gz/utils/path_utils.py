"""
Path resolution utilities for MCP services.

All services use a unified strict relative-path convention:
- Input/output paths must be relative, starting with "workspace/"
- SANDBOX_ROOT (/workspace) is used for input resolution (read any sandbox file)
- WORKSPACE_ROOT is used for output resolution (write to userdata area)
- Return values use the relative "workspace/..." form, never absolute paths
"""

import os
import re
from typing import Tuple


# ---------- Workspace constants ----------
SANDBOX_ROOT = os.environ.get("MCP_SHARED_PATH", "/workspace")
WORKSPACE_ROOT = os.environ.get("MCP_WORKSPACE_ROOT", "/workspace/workspace")
# Game-runtime tree — the directory the game server + as-mate read game assets
# from (`<root>/games/<id>/public/assets/...`), which is the SAME tree
# write_file / agentic_os write to via the cwd-relative `games/<id>` form.
#
# This is DECOUPLED from SANDBOX_ROOT on purpose. In production the MCP
# container's userdata mount is doubly-nested (MCP_SHARED_PATH=/workspace/
# workspace), but the game-runtime tree stays at /workspace/games. If the
# `games/` route reused SANDBOX_ROOT, assets would land at /workspace/workspace/
# games/<id>/... — invisible to the runtime, as-mate, and the production-tracker
# scan (all of which read /workspace/games/<id>/...). Keeping it on its own
# root (default /workspace, overridable via MCP_GAME_RUNTIME_ROOT) fixes game
# asset placement WITHOUT moving input resolution or image/audio staging, so no
# other profile/category is affected.
GAME_RUNTIME_ROOT = os.environ.get("MCP_GAME_RUNTIME_ROOT", "/workspace")
WORKSPACE_PREFIX = "workspace/"

# Top-level subdirectory → physical root mapping for MCP outputs.
# Caller passes a workspace-relative path like "workspace/<top>/<rest>"; the
# top-level segment selects the physical root, and <rest> resolves underneath.
#
# - WORKSPACE_ROOT entries land in /workspace/workspace/<top>/<rest>
#   (the userdata area, host-mounted at data/workspace/workspace/...).
# - GAME_RUNTIME_ROOT entries land in /workspace/<top>/<rest>
#   (the game-runtime tree; this is where games/<id>/ lives and the game
#   server reads from directly).
#
# Anything not in this table is rejected by validate_output_path.
OUTPUT_ROUTING: dict[str, str] = {
    "images":   WORKSPACE_ROOT,
    "audio":    WORKSPACE_ROOT,
    "asset3d":  WORKSPACE_ROOT,
    "games":    GAME_RUNTIME_ROOT,
}


def get_audio_output_dir(subdir: str = "") -> str:
    """Get the audio output directory (WORKSPACE_ROOT/audio[/subdir]).

    Args:
        subdir: Optional subdirectory under audio/, e.g. "bgm" or "sfx".
                If empty, returns WORKSPACE_ROOT/audio/.
    """
    audio_dir = os.path.join(WORKSPACE_ROOT, "audio", subdir) if subdir else os.path.join(WORKSPACE_ROOT, "audio")
    os.makedirs(audio_dir, exist_ok=True)
    return audio_dir


def get_asset3d_output_dir() -> str:
    """Get the 3D asset output directory (WORKSPACE_ROOT/asset3d)."""
    asset3d_dir = os.path.join(WORKSPACE_ROOT, "asset3d")
    os.makedirs(asset3d_dir, exist_ok=True)
    return asset3d_dir


# =====================================================================
# Image-service path functions (strict relative-path convention)
# =====================================================================

def _normalize_workspace_path(path: str) -> str:
    """Strip leading ./ and normalize slashes for workspace-relative paths."""
    norm = path.replace("\\", "/").strip()
    if norm.startswith("./"):
        norm = norm[2:]
    return norm


def _resolve_workspace(relative_suffix: str) -> str:
    """Map a workspace-relative suffix to the container-internal absolute path."""
    return os.path.normpath(os.path.join(WORKSPACE_ROOT, relative_suffix))


def _abs_to_relative_hint(abspath: str) -> str:
    """Try to convert an absolute container path to a usable relative path."""
    # /app/agentic_os/.agentic_os/sessions/... → agentic_os/sessions/...
    if "/.agentic_os/" in abspath:
        return "agentic_os/" + abspath.split("/.agentic_os/", 1)[1]
    # /workspace/X → X
    sandbox = os.path.normpath(SANDBOX_ROOT)
    if abspath.startswith(sandbox + "/"):
        return abspath[len(sandbox) + 1:]
    return ""


def validate_input_path(path: str) -> Tuple[bool, str]:
    """Validate and resolve an input path for image services.

    Rules:
    - Paths starting with "workspace/" have the prefix stripped
    - Other relative paths are resolved directly under SANDBOX_ROOT
    - Absolute paths (starting with ``/``) are rejected
    - Paths containing ``..`` are rejected
    - The resolved file must exist on disk

    Returns:
        (True, resolved_absolute_path) on success
        (False, error_message) on failure
    """
    if not path or not path.strip():
        return False, "Input path is empty."

    norm = _normalize_workspace_path(path)

    if norm.startswith("/"):
        # Auto-suggest the correct relative path
        suggestion = _abs_to_relative_hint(norm)
        hint = f" Try: {suggestion}" if suggestion else ""
        return False, (
            f"Absolute paths are not accepted.{hint} (got: {path})"
        )

    if ".." in norm:
        return False, (
            f"Path must not contain '..'. "
            f"Use a relative path like workspace/images/xxx.png (got: {path})"
        )

    # Resolve under SANDBOX_ROOT first (sandbox-wide reads), then fall back to
    # WORKSPACE_ROOT (userdata writes). Without the fallback, `workspace/X`
    # written by an output service can't be read back by an input service —
    # outputs land in WORKSPACE_ROOT/X but inputs only check SANDBOX_ROOT/X.
    suffix = norm[len(WORKSPACE_PREFIX):] if norm.startswith(WORKSPACE_PREFIX) else norm
    top = suffix.split("/", 1)[0] if suffix else ""
    # Game assets resolve under the game-runtime tree (GAME_RUNTIME_ROOT) — the
    # same tree the game server / as-mate read and write_file writes to — which
    # production mounts separately from the doubly-nested userdata SANDBOX_ROOT.
    # Everything else resolves under SANDBOX_ROOT (sandbox-wide reads).
    is_runtime_category = OUTPUT_ROUTING.get(top) == GAME_RUNTIME_ROOT
    primary_root = GAME_RUNTIME_ROOT if is_runtime_category else SANDBOX_ROOT
    primary_resolved = os.path.normpath(os.path.join(primary_root, suffix))
    if os.path.exists(primary_resolved):
        return True, primary_resolved

    # Fall back to WORKSPACE_ROOT (userdata writes) so `workspace/X` outputs by
    # an image/audio service can be read back by an input service — outputs land
    # in WORKSPACE_ROOT/X but the primary check above only looks under
    # SANDBOX_ROOT/X. NOT for runtime-routed categories (games): a hit ONLY at
    # the userdata path means the asset was MISplaced at the doubly-nested
    # /workspace/workspace/games/... location, where the runtime/as-mate can't
    # see it. Silently reading it masks the misplacement and the asset 404s at
    # runtime — refuse and point at the fix instead.
    workspace_resolved = os.path.normpath(os.path.join(WORKSPACE_ROOT, suffix))
    if workspace_resolved != primary_resolved and os.path.exists(workspace_resolved):
        if is_runtime_category:
            return False, (
                f"'{top}/...' asset exists only at the userdata staging path "
                f"({workspace_resolved}), not at the runtime path the game server "
                f"serves ({primary_resolved}). It must be written under the game "
                f"runtime tree (games/ → MCP_GAME_RUNTIME_ROOT), not the userdata "
                f"area. (got: {path})"
            )
        return True, workspace_resolved

    return False, f"File not found: {path}"


# Magic-byte signatures for the image formats the image pipeline accepts.
_IMAGE_MAGIC_BYTES = (
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"GIF87a", "image/gif"),
    (b"GIF89a", "image/gif"),
)


def validate_base64_image(b64_data: str) -> Tuple[bool, str]:
    """Validate that a string is legal base64-encoded image data.

    Guards the ``inputImageBase64s`` path against non-image payloads — most
    importantly context-slimming placeholder text (e.g. a localized
    "image uploaded by user" stub) that an upstream caller may forward
    verbatim. Such values are not valid base64 and would otherwise blow up
    deep inside the decoder with an opaque, implementation-leaking error
    (`string argument should contain only ASCII characters`).

    Returns:
        (True, "") when the string decodes to a recognized image format.
        (False, error_message) otherwise. The error is provider-neutral and
        tells the model to pass a file path instead.
    """
    import base64 as _b64
    import binascii as _binascii

    if not b64_data or not b64_data.strip():
        return False, "Image data is empty. Pass the file path via inputImagePaths instead."

    payload = b64_data.strip()
    # Tolerate an optional data-URL prefix (e.g. "data:image/png;base64,....").
    if payload.startswith("data:") and "," in payload:
        payload = payload.split(",", 1)[1]

    # Base64 is ASCII-only by definition; non-ASCII text (such as a CJK
    # placeholder string) can never be valid and must be rejected before decode.
    if not payload.isascii():
        return False, (
            "Image data is invalid (received placeholder or non-image text, not base64). "
            "For user-uploaded images, pass the file path via inputImagePaths instead of inputImageBase64s."
        )

    try:
        raw = _b64.b64decode(payload, validate=True)
    except (ValueError, _binascii.Error):
        return False, (
            "Image data is not valid base64. "
            "For user-uploaded images, pass the file path via inputImagePaths instead of inputImageBase64s."
        )

    if len(raw) < 12:
        return False, "Image data is too small to be a valid image."

    # WebP: "RIFF"...."WEBP"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return True, ""
    for sig, _mime in _IMAGE_MAGIC_BYTES:
        if raw.startswith(sig):
            return True, ""

    return False, (
        "Image data does not look like a supported image (JPEG/PNG/GIF/WebP). "
        "For user-uploaded images, pass the file path via inputImagePaths instead of inputImageBase64s."
    )


def validate_output_path(path: str, required_subdir: str | None = None) -> Tuple[bool, str]:
    """Validate and resolve an output path for image / asset services.

    Routing rules (top-level segment after `workspace/`):
    - Top-level in OUTPUT_ROUTING → resolve under the matching root
      (`images`, `audio`, `asset3d` → WORKSPACE_ROOT;
      `games` → SANDBOX_ROOT, e.g. `workspace/games/<gid>/public/assets/X.png`
      → `/workspace/games/<gid>/public/assets/X.png`).
    - Top-level NOT in OUTPUT_ROUTING → reject, **unless** `required_subdir`
      is explicitly passed by the caller (legacy escape hatch for
      happyhorse-video, minimax-music, etc.); in that case the route
      defaults to WORKSPACE_ROOT and the prefix gate is the only check.
    - Absolute paths and any path containing `..` are rejected.
    - For the `games` route, the caller MUST stay under
      `games/<gid>/public/assets/` — anything else (source code, package
      manifests, `.workbench/`, `docs/`, `.git/`) is `write_file` /
      `edit_file` territory and is rejected here. `<gid>` must look like
      a UUID (32+ hex/dash chars) to prevent typo-driven sibling
      pollution.

    Returns:
        (True, resolved_absolute_path) on success
        (False, error_message) on failure
    """
    if not path or not path.strip():
        return False, "Output path is empty."

    norm = _normalize_workspace_path(path)

    if norm.startswith("/"):
        return False, (
            f"Absolute paths are not accepted. "
            f"Use a relative path like workspace/images/xxx.png (got: {path})"
        )

    if ".." in norm:
        return False, (
            f"Path must not contain '..'. "
            f"Use a relative path like workspace/images/xxx.png (got: {path})"
        )

    # The `workspace/` prefix is OPTIONAL. The same path string must resolve
    # identically whether it came from an MCP `outputPath`, the in-process
    # `write_file` tool, or bash — so a game asset can use its bash/cwd-natural
    # `games/<gid>/public/assets/...` form (no prefix) without the
    # `workspace/games/...` form double-nesting under WORKSPACE_ROOT in bash.
    # The real guard is `top in OUTPUT_ROUTING` below, not the prefix. (A
    # doubly-prefixed `workspace/workspace/...` strips to top=`workspace`, which
    # is not a routing key, so it is still rejected.)
    suffix = norm[len(WORKSPACE_PREFIX):] if norm.startswith(WORKSPACE_PREFIX) else norm
    top, _, rest = suffix.partition("/")
    if not top:
        return False, f"Output path missing top-level segment: {path}"

    # Legacy callers (e.g. happyhorse-video required_subdir="videos") that
    # write to top-levels NOT in OUTPUT_ROUTING get a back-compat path:
    # require_subdir prefix-gates and routes to WORKSPACE_ROOT.
    if required_subdir is not None:
        if not suffix.startswith(f"{required_subdir}/"):
            return False, (
                f"Output path must be under '{required_subdir}/' "
                f"(leading '{WORKSPACE_PREFIX}' optional). Got: {path}"
            )
        resolved = os.path.normpath(os.path.join(WORKSPACE_ROOT, suffix))
        parent = os.path.dirname(resolved)
        if parent:
            os.makedirs(parent, exist_ok=True)
        return True, resolved

    if top not in OUTPUT_ROUTING:
        allowed = ", ".join(sorted(OUTPUT_ROUTING))
        return False, (
            f"Output top-level '{top}' is not allowed (got: {path}). "
            f"Allowed: {allowed}"
        )

    # `games` route enforces game-id shape and the public/assets/ sub-path.
    if top == "games":
        ok, msg = _validate_games_subpath(rest, original=path)
        if not ok:
            return False, msg

    root = OUTPUT_ROUTING[top]
    resolved = os.path.normpath(os.path.join(root, suffix))

    parent = os.path.dirname(resolved)
    if parent:
        os.makedirs(parent, exist_ok=True)

    return True, resolved


_GID_RE = re.compile(
    r"^("
    r"[0-9a-fA-F]{32}"
    r"|"
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
    r")$"
)


def _validate_games_subpath(rest: str, *, original: str) -> Tuple[bool, str]:
    """Enforce shape: <gid>/public/assets/<rest_of_path>."""
    if not rest:
        return False, f"games/ output requires a game id (got: {original})"
    gid, _, after_gid = rest.partition("/")
    if not _GID_RE.match(gid):
        return False, (
            f"games/<gid>/ segment must be a UUID-shaped game id (got gid={gid!r}, path={original})"
        )
    if not after_gid.startswith("public/assets/"):
        return False, (
            f"games/<gid>/ outputs must stay under public/assets/ "
            f"(got: {original}). Source code, .git, .workbench/, and docs/ "
            f"are write_file territory."
        )
    return True, ""


def validate_output_dir(path: str, required_subdir: str | None = None) -> Tuple[bool, str]:
    """Validate and resolve an output *directory* path.

    Same routing as :func:`validate_output_path`. Trailing slashes are
    tolerated. The directory is created if missing.
    """
    if not path or not path.strip():
        return False, "Output directory must not be empty."

    norm = _normalize_workspace_path(path).rstrip("/")

    if norm.startswith("/"):
        return False, (
            f"Absolute paths are not accepted (got: {path})"
        )

    if ".." in norm:
        return False, (f"Path must not contain '..' (got: {path})")

    # `workspace/` prefix optional — see validate_output_path.
    suffix = norm[len(WORKSPACE_PREFIX):] if norm.startswith(WORKSPACE_PREFIX) else norm
    top, _, rest = suffix.partition("/")
    if not top:
        return False, f"Output directory missing top-level segment: {path}"

    if required_subdir is not None:
        if suffix != required_subdir and not suffix.startswith(required_subdir + "/"):
            return False, (
                f"Output directory must be under '{required_subdir}/' "
                f"(leading '{WORKSPACE_PREFIX}' optional). Got: {path}"
            )
        resolved = os.path.normpath(os.path.join(WORKSPACE_ROOT, suffix))
        os.makedirs(resolved, exist_ok=True)
        return True, resolved

    if top not in OUTPUT_ROUTING:
        allowed = ", ".join(sorted(OUTPUT_ROUTING))
        return False, (
            f"Output top-level '{top}' is not allowed (got: {path}). "
            f"Allowed: {allowed}"
        )

    if top == "games":
        ok, msg = _validate_games_subpath(rest, original=path)
        if not ok:
            return False, msg

    root = OUTPUT_ROUTING[top]
    resolved = os.path.normpath(os.path.join(root, suffix))
    os.makedirs(resolved, exist_ok=True)
    return True, resolved


def resolve_output_dir(requested: str | None, default_factory) -> Tuple[str | None, str | None]:
    """Pick the output directory for a retrieval / download tool.

    Retrieval tools (``asset3d-search``, ``vibe-music-search``) batch-download
    several files into one directory. They keep a hardcoded default sink, but
    also accept an optional caller-supplied ``output_dir`` so the assets can land
    in the active game's runtime tree (``workspace/games/<gid>/public/assets/...``)
    instead of the shared staging area.

    - ``requested`` blank / whitespace / ``None`` → call ``default_factory()`` and
      return its directory (original behavior, unchanged).
    - ``requested`` non-blank → validate + resolve via :func:`validate_output_dir`
      (same routing/rejection rules) and return the resolved absolute directory.

    Returns ``(resolved_dir, error_message)`` where exactly one element is
    non-None: on success ``(dir, None)``; on a rejected path ``(None, msg)``.
    """
    if not requested or not str(requested).strip():
        return default_factory(), None
    ok, resolved = validate_output_dir(requested)
    if not ok:
        return None, resolved
    return resolved, None


def to_external_path(internal_path: str) -> str:
    """Convert a container-internal absolute path to the external relative form.

    Uses MCP_SHARED_PATH (the mount point, typically /workspace) as the base
    so the returned path is consumable by the agent's tools (read_file, send_media).

    ``/workspace/workspace/images/foo.png`` -> ``workspace/workspace/images/foo.png``

    If the path does not start with the shared mount, returns it unchanged.
    """
    norm = os.path.normpath(internal_path)

    # --- Change 2: try WORKSPACE_ROOT first (more specific), then SANDBOX_ROOT ---
    ws_norm = os.path.normpath(WORKSPACE_ROOT)
    if ws_norm != os.path.normpath(SANDBOX_ROOT):
        if norm == ws_norm:
            return "workspace"
        if norm.startswith(ws_norm + os.sep):
            return WORKSPACE_PREFIX + norm[len(ws_norm) + 1:]

    shared = os.path.normpath(SANDBOX_ROOT)
    if norm == shared:
        return "workspace"

    if norm.startswith(shared + os.sep):
        return "workspace/" + norm[len(shared) + 1:]

    # Game-runtime tree (decoupled `games/` route) may differ from SANDBOX_ROOT
    # in production — map those assets back to the external `workspace/...` form
    # too. Checked last because GAME_RUNTIME_ROOT (/workspace) is a prefix of the
    # doubly-nested userdata roots, so the more-specific ones match first.
    grr = os.path.normpath(GAME_RUNTIME_ROOT)
    if grr not in (ws_norm, shared):
        if norm == grr:
            return "workspace"
        if norm.startswith(grr + os.sep):
            return "workspace/" + norm[len(grr) + 1:]

    return internal_path
