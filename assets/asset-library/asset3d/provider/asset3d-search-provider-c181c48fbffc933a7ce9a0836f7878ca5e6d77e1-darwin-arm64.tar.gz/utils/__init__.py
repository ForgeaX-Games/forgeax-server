"""
MCP Servers Utilities Python Module

Provides common utilities for all MCP servers:
- HTTP transport for MCP over HTTP
- Path resolution utilities for Docker/host path mapping
- Request logging
"""

from .http_transport import (
    run_http_server,
    get_region,
    is_oversea,
    get_request_config,
    RequestConfig,
)
from .path_utils import (
    get_audio_output_dir,
    get_asset3d_output_dir,
    validate_input_path,
    validate_base64_image,
    validate_output_path,
    validate_output_dir,
    resolve_output_dir,
    to_external_path,
    SANDBOX_ROOT,
    WORKSPACE_ROOT,
    OUTPUT_ROUTING,
)
from .mcp_request_log import append_mcp_request_log

__all__ = [
    "run_http_server",
    "get_region",
    "is_oversea",
    "get_request_config",
    "RequestConfig",
    "get_audio_output_dir",
    "get_asset3d_output_dir",
    "validate_input_path",
    "validate_base64_image",
    "validate_output_path",
    "validate_output_dir",
    "resolve_output_dir",
    "to_external_path",
    "SANDBOX_ROOT",
    "WORKSPACE_ROOT",
    "OUTPUT_ROUTING",
    "append_mcp_request_log",
]
