#!/usr/bin/env python3
"""Verify and provision an Asset3D provider archive without source checkout."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import venv
import zipfile
from pathlib import Path
from typing import Any


SCHEMA = "forgeax.asset3d-provider-bundle/1.0.0"
MAX_MEMBER_BYTES = 1024 * 1024 * 1024
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
WHEEL_HASH_RE = re.compile(r"--hash=sha256:([0-9a-f]{64})")
WHEEL_NAME_RE = re.compile(r"^Name:\s*(.+?)\s*$", re.MULTILINE)
WHEEL_VERSION_RE = re.compile(r"^Version:\s*(.+?)\s*$", re.MULTILINE)
FORBIDDEN_PATH_PARTS = {".venv", "venv", "__pycache__", ".env", "credentials", "credential", "secrets"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalise_name(value: str) -> str:
    return re.sub(r"[-_.]+", "-", value.strip().lower())


def _wheel_identity(path: Path) -> tuple[str, str]:
    try:
        with zipfile.ZipFile(path) as wheel:
            metadata_name = next(name for name in wheel.namelist() if name.endswith(".dist-info/METADATA"))
            metadata = wheel.read(metadata_name).decode("utf-8")
    except (OSError, StopIteration, UnicodeError, zipfile.BadZipFile) as exc:
        raise ValueError("wheel metadata is invalid") from exc
    name_match = WHEEL_NAME_RE.search(metadata)
    version_match = WHEEL_VERSION_RE.search(metadata)
    if not name_match or not version_match:
        raise ValueError("wheel metadata is incomplete")
    return _normalise_name(name_match.group(1)), version_match.group(1).strip()


def _safe_member(name: str) -> str:
    if not name or "\x00" in name or name.startswith("/") or "\\" in name:
        raise ValueError("bundle member path is invalid")
    parts = name.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError("bundle member path is invalid")
    return name


def _extract_archive(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=False)
    seen: set[str] = set()
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            name = _safe_member(member.name)
            if name in seen:
                raise ValueError("bundle contains duplicate path")
            seen.add(name)
            if member.issym() or member.islnk() or member.isdev() or not member.isfile():
                raise ValueError("bundle contains an unsupported file type")
            if member.size < 0 or member.size > MAX_MEMBER_BYTES:
                raise ValueError("bundle member exceeds size limit")
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            if os.path.commonpath([str(destination.resolve()), str(target.resolve())]) != str(destination.resolve()):
                raise ValueError("bundle member escapes staging")
            source = tar.extractfile(member)
            if source is None:
                raise ValueError("bundle member is unreadable")
            with target.open("xb") as output:
                shutil.copyfileobj(source, output, 1024 * 1024)
            os.chmod(target, member.mode & 0o777)


def _inventory(stage: Path, *, allow_managed_venv: bool = False) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(stage.rglob("*"), key=lambda value: value.relative_to(stage).as_posix().encode("utf-8")):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(stage).as_posix()
        if allow_managed_venv and relative.startswith("venv/"):
            continue
        # The manifest describes the payload inventory.  Including the
        # manifest itself would create a self-hash cycle.
        if relative == "bundle-manifest.json":
            continue
        if any(part in FORBIDDEN_PATH_PARTS for part in relative.split("/")):
            raise ValueError("bundle contains a credential/cache/venv path")
        rows.append({"path": relative, "sha256": sha256_file(path), "bytes": path.stat().st_size, "mode": stat.S_IMODE(path.stat().st_mode)})
    return rows


def verify_stage(stage: Path, *, allow_managed_venv: bool = False) -> dict[str, Any]:
    manifest_path = stage / "bundle-manifest.json"
    if not manifest_path.is_file() or manifest_path.is_symlink():
        raise ValueError("bundle manifest is missing")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict) or manifest.get("schema") != SCHEMA:
        raise ValueError("bundle schema is invalid")
    if not re.fullmatch(r"[0-9a-f]{40}", str(manifest.get("providerCommit", ""))):
        raise ValueError("provider commit is invalid")
    if manifest.get("python") != ">=3.11,<3.13":
        raise ValueError("python range is invalid")
    required = {
        "asset3d-search/server.py",
        "schemas/result-1.0.0.json",
        "schemas/receipt-1.0.0.json",
        "requirements.lock",
        "bin/FBX2glTF",
        "licenses/FBX2glTF-LICENSE.txt",
        "verify/verify_asset3d_bundle.py",
        "bin/asset3d-search",
    }
    actual_files = {path.relative_to(stage).as_posix() for path in stage.rglob("*") if path.is_file() and not path.is_symlink()}
    if not required.issubset(actual_files):
        raise ValueError("bundle is missing a required file")
    inventory = manifest.get("inventory")
    if not isinstance(inventory, list):
        raise ValueError("bundle inventory is invalid")
    expected = sorted(inventory, key=lambda row: str(row.get("path", "")).encode("utf-8"))
    actual = _inventory(stage, allow_managed_venv=allow_managed_venv)
    if expected != actual:
        raise ValueError("bundle inventory digest does not match")
    result_schema = manifest.get("resultSchema")
    receipt_schema = manifest.get("receiptSchema")
    converter = manifest.get("converter")
    lock = manifest.get("requirementsLock")
    if not isinstance(result_schema, dict) or result_schema.get("path") != "schemas/result-1.0.0.json" or not SHA_RE.fullmatch(str(result_schema.get("sha256", ""))):
        raise ValueError("result schema metadata is invalid")
    if sha256_file(stage / "schemas/result-1.0.0.json") != result_schema["sha256"]:
        raise ValueError("result schema digest mismatch")
    if not isinstance(receipt_schema, dict) or receipt_schema.get("path") != "schemas/receipt-1.0.0.json" or not SHA_RE.fullmatch(str(receipt_schema.get("sha256", ""))):
        raise ValueError("receipt schema metadata is invalid")
    if sha256_file(stage / "schemas/receipt-1.0.0.json") != receipt_schema["sha256"]:
        raise ValueError("receipt schema digest mismatch")
    if not isinstance(converter, dict) or converter.get("path") != "bin/FBX2glTF" or converter.get("licensePath") != "licenses/FBX2glTF-LICENSE.txt" or not SHA_RE.fullmatch(str(converter.get("sha256", ""))):
        raise ValueError("converter metadata is invalid")
    if sha256_file(stage / "bin/FBX2glTF") != converter["sha256"]:
        raise ValueError("converter digest mismatch")
    if not isinstance(lock, dict) or lock.get("path") != "requirements.lock" or not SHA_RE.fullmatch(str(lock.get("sha256", ""))):
        raise ValueError("lock metadata is invalid")
    if sha256_file(stage / "requirements.lock") != lock["sha256"]:
        raise ValueError("lock digest mismatch")
    lock_text = (stage / "requirements.lock").read_text(encoding="utf-8")
    locked: dict[str, tuple[str, set[str]]] = {}
    for line in lock_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("--"):
            continue
        if "==" not in stripped:
            raise ValueError("lock is not version pinned")
        hashes = set(WHEEL_HASH_RE.findall(stripped))
        if not hashes:
            raise ValueError("lock is not hash pinned")
        name, version = stripped.split("==", 1)
        version = version.split()[0]
        key = _normalise_name(name)
        if key in locked:
            raise ValueError("lock repeats a package")
        locked[key] = (version, hashes)
    wheelhouse = stage / "wheelhouse"
    wheels = sorted(wheelhouse.glob("*.whl")) if wheelhouse.is_dir() else []
    if not wheels:
        raise ValueError("bundle wheelhouse is empty")
    if any(path.is_symlink() for path in wheels):
        raise ValueError("bundle wheelhouse contains a symlink")
    # Multiple wheels for one pinned distribution are expected when the
    # archive supports both Python 3.11 and 3.12 or multiple target tags.
    # Every wheel digest must be explicitly present on that package's lock row.
    actual: dict[str, tuple[str, set[str]]] = {}
    for wheel in wheels:
        name, version = _wheel_identity(wheel)
        digest = sha256_file(wheel)
        if name in actual:
            old_version, hashes = actual[name]
            if old_version != version:
                raise ValueError("bundle wheelhouse repeats a package at multiple versions")
            hashes.add(digest)
        else:
            actual[name] = (version, {digest})
    if set(actual) != set(locked):
        raise ValueError("lock and wheelhouse package sets differ")
    for name, (version, digests) in actual.items():
        locked_version, hashes = locked[name]
        if version != locked_version or digests != hashes:
            raise ValueError("wheel does not match requirements lock")
    return manifest


def verify_archive(archive: Path, expected_sha256: str | None = None) -> dict[str, Any]:
    if expected_sha256 is not None and sha256_file(archive) != expected_sha256:
        raise ValueError("archive sha256 mismatch")
    with tempfile.TemporaryDirectory(prefix="asset3d-verify-") as temporary:
        stage = Path(temporary) / "bundle"
        _extract_archive(archive, stage)
        return verify_stage(stage)


def _python_ok(executable: str) -> bool:
    completed = subprocess.run([executable, "-c", "import sys; print(sys.version_info[:2])"], capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        return False
    try:
        major, minor = eval(completed.stdout.strip(), {"__builtins__": {}}, {})
    except Exception:
        return False
    return major == 3 and 11 <= minor < 13


def provision(archive: Path, cache: Path, expected_sha256: str | None, python_executable: str) -> dict[str, Any]:
    if expected_sha256 is not None and sha256_file(archive) != expected_sha256:
        raise ValueError("archive sha256 mismatch")
    if not _python_ok(python_executable):
        raise ValueError("system Python must be >=3.11 and <3.13")
    if cache.exists() or cache.is_symlink():
        raise ValueError("managed provider cache already exists")
    with tempfile.TemporaryDirectory(prefix="asset3d-provision-") as temporary:
        stage = Path(temporary) / "bundle"
        _extract_archive(archive, stage)
        manifest = verify_stage(stage)
        managed = Path(temporary) / "managed"
        managed.mkdir(mode=0o700)
        venv_dir = managed / "venv"
        venv.EnvBuilder(with_pip=True, clear=True, symlinks=False).create(venv_dir)
        venv_python = venv_dir / "bin/python"
        if not venv_python.exists():
            venv_python = venv_dir / "Scripts/python.exe"
        command = [str(venv_python), "-m", "pip", "install", "--no-index", "--require-hashes", "--find-links", str(stage / "wheelhouse"), "-r", str(stage / "requirements.lock")]
        completed = subprocess.run(command, capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            raise ValueError("offline wheelhouse installation failed")
        imports = subprocess.run([str(venv_python), "-c", "import aiohttp, mcp"], capture_output=True, text=True, check=False)
        if imports.returncode != 0:
            raise ValueError("managed provider imports failed")
        final = Path(temporary) / "final"
        final.mkdir(mode=0o700)
        for child in stage.iterdir():
            destination = final / child.name
            if child.is_dir():
                shutil.copytree(child, destination, symlinks=False)
            else:
                shutil.copy2(child, destination)
        shutil.move(str(venv_dir), str(final / "venv"))
        cache.parent.mkdir(parents=True, exist_ok=True)
        os.replace(final, cache)
    verify_stage(cache, allow_managed_venv=True)
    managed_python = cache / "venv/bin/python"
    if not managed_python.is_file():
        managed_python = cache / "venv/Scripts/python.exe"
    launcher = cache / "bin/asset3d-search"
    converter = cache / "bin/FBX2glTF"
    if not managed_python.is_file() or not os.access(managed_python, os.X_OK):
        raise ValueError("managed provider interpreter is missing after provision")
    if not launcher.is_file() or not os.access(launcher, os.X_OK):
        raise ValueError("managed provider launcher is missing after provision")
    if not converter.is_file() or not os.access(converter, os.X_OK):
        raise ValueError("managed provider converter is missing after provision")
    return {
        "cache": str(cache),
        "converter": str(converter),
        "launcher": str(launcher),
        "providerCommit": manifest["providerCommit"],
        "python": str(managed_python),
        "sha256": expected_sha256 or sha256_file(archive),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--archive")
    source.add_argument("--stage")
    parser.add_argument("--sha256")
    parser.add_argument("--provision")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    expected = args.sha256.strip().lower() if args.sha256 else None
    if expected and not SHA_RE.fullmatch(expected):
        raise SystemExit("--sha256 must be lowercase hex")
    if args.stage:
        if args.provision or expected:
            raise SystemExit("--stage cannot be combined with --provision or --sha256")
        result = verify_stage(Path(args.stage).resolve(), allow_managed_venv=True)
    elif args.provision:
        result = provision(Path(args.archive).resolve(), Path(args.provision).resolve(), expected, args.python)
    else:
        result = verify_archive(Path(args.archive).resolve(), expected)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
