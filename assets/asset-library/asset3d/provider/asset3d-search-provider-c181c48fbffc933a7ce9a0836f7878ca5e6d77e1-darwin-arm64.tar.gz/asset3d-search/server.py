#!/usr/bin/env python3
"""Hardened Asset3D search MCP provider.

The provider deliberately keeps the historical ``search_asset`` tool shape for
older hosts.  A Game Plugin caller requests ``output_format=glb`` and receives
the checked ``forgeax.asset3d-search-result/1.0.0`` envelope.  Download URLs,
candidate records and credentials are private implementation data: they never
appear in logs or public result rows.
"""

from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import os
import posixpath
import re
import shutil
import ssl
import stat
import subprocess
import sys
import time
import uuid
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urljoin, urlsplit

# A bundle runs ``asset3d-search/server.py`` directly while its audited shared
# utilities live one directory above it.  This keeps the archive self-contained
# without depending on the source checkout's process cwd.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# The source checkout is intentionally importable without its runtime venv.
# The managed bundle installs these dependencies before starting the provider;
# unit/security tests can import pure helpers on a bare Python installation.
try:  # pragma: no cover - exercised by the real managed bundle
    import aiohttp  # type: ignore
except ImportError:  # pragma: no cover - covered by bare-environment tests
    aiohttp = None  # type: ignore

try:  # pragma: no cover - exercised by the real managed bundle
    import certifi  # type: ignore
except ImportError:  # pragma: no cover - source-only helper tests may omit it
    certifi = None  # type: ignore

try:  # pragma: no cover - exercised by the real managed bundle
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import CallToolResult, TextContent, Tool
except ImportError:  # pragma: no cover - small compatibility shim for helpers
    class TextContent:  # type: ignore[no-redef]
        def __init__(self, *, type: str, text: str) -> None:
            self.type = type
            self.text = text

    class CallToolResult:  # type: ignore[no-redef]
        def __init__(self, *, content: list[TextContent], isError: bool = False) -> None:
            self.content = content
            self.isError = isError

    class Tool:  # type: ignore[no-redef]
        def __init__(self, *, name: str, description: str, inputSchema: dict[str, Any]) -> None:
            self.name = name
            self.description = description
            self.inputSchema = inputSchema

    class Server:  # type: ignore[no-redef]
        def __init__(self, _name: str) -> None:
            pass

        def list_tools(self):
            return lambda fn: fn

        def call_tool(self):
            return lambda fn: fn

        def create_initialization_options(self) -> dict[str, Any]:
            return {}

        async def run(self, *_args: Any, **_kwargs: Any) -> None:
            raise RuntimeError("mcp dependency is not installed")

    class _MissingStdio:
        async def __aenter__(self):
            raise RuntimeError("mcp dependency is not installed")

        async def __aexit__(self, *_args: Any) -> None:
            return None

    def stdio_server():  # type: ignore[no-redef]
        return _MissingStdio()

try:
    from utils.path_utils import to_external_path
except ImportError:  # pragma: no cover - bundle always includes audited utils
    def to_external_path(path: str) -> str:  # type: ignore[misc]
        return path


# ---------------------------------------------------------------------------
# Frozen provider contract and budgets
# ---------------------------------------------------------------------------

SCHEMA_VERSION = "forgeax.asset3d-search-result/1.0.0"
RECEIPT_SCHEMA_VERSION = "forgeax.asset3d-search-receipt/1.0.0"
BUNDLE_SCHEMA_VERSION = "forgeax.asset3d-provider-bundle/1.0.0"
PROVIDER_NAME = "ea-3d"
PROVIDER_COMMIT = "8360c56050863272dd47827200d6fc783f745d90"

MAX_QUERIES = 16
MAX_REDIRECTS = 3
MAX_CONCURRENT_SEARCHES = 10
MAX_CONCURRENT_DOWNLOADS = 3
SEARCH_ITEM_TIMEOUT_SECONDS = 30.0
SEARCH_BATCH_TIMEOUT_SECONDS = 60.0
DOWNLOAD_ITEM_TIMEOUT_SECONDS = 120.0
WORK_DEADLINE_SECONDS = 180.0
CLEANUP_TIMEOUT_SECONDS = 5.0
MAX_DOWNLOAD_BYTES = 256 * 1024 * 1024
MAX_ARCHIVE_EXPANDED_BYTES = 512 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 1024
MAX_FILE_BYTES = 128 * 1024 * 1024
MAX_EXPANSION_RATIO = 100
MAX_RESULT_BYTES = 1 * 1024 * 1024
MAX_GLB_BYTES = 256 * 1024 * 1024
MAX_CATALOG_BYTES = 8 * 1024 * 1024
MAX_CATALOG_RECORDS = 10_000

# Keep the old parameter behavior for callers outside Game Plugin.  The
# canonical Game Plugin path always passes ``glb`` explicitly.
SUPPORTED_OUTPUT_FORMATS = {"glb", "fbx"}
DEFAULT_OUTPUT_FORMAT = "fbx"
MODEL_EXTS = {".fbx", ".glb", ".gltf", ".obj"}
_IGNORED_FILES = {"meta.json"}

AW_API_BASE_URL = os.environ.get(
    "AW_API_BASE_URL", "http://127.0.0.1:9000/v1/out/omcontentserver"
)
# Credentials are supplied only by the managed runtime environment or a
# permission-checked user credential file.  Keeping no source fallback here is
# important because this file is copied verbatim into the provider archive.
AW_API_SANDBOX_KEY = os.environ.get("AW_API_SANDBOX_KEY", "")
AW_API_CREDENTIAL_FILE = os.environ.get("AW_API_CREDENTIAL_FILE", "")
AW_API_DEPOT_NAME = os.environ.get("AW_API_DEPOT_NAME", "aw")
AW_API_TIMEOUT = SEARCH_ITEM_TIMEOUT_SECONDS
ASSET3D_CATALOG_BASE_URL = os.environ.get("ASSET3D_CATALOG_BASE_URL", "").rstrip("/")
LLM_USER_ID = os.environ.get("LLM_USER_ID", "user_aw_websvr")
LLM_VOTE_ROUNDS = 3


class ProviderError(Exception):
    """Internal error carrying only a public contract code/message."""

    def __init__(self, code: str, message: str, *, retryable: bool = False) -> None:
        super().__init__(message)
        self.code = code
        self.message = _redact_message(message)
        self.retryable = retryable


class DeadlineExceeded(ProviderError):
    def __init__(self, code: str = "batch_timeout") -> None:
        super().__init__(code, "provider work deadline exceeded", retryable=True)


ERROR_CODES = {
    "asset_not_found",
    "asset_identity_missing",
    "search_timeout",
    "search_upstream_error",
    "download_timeout",
    "download_origin_rejected",
    "download_too_large",
    "archive_rejected",
    "conversion_failed",
    "digest_failed",
    "batch_timeout",
    "internal_error",
}
RETRYABLE_CODES = {
    "search_timeout",
    "search_upstream_error",
    "download_timeout",
    "download_origin_rejected",
    "download_too_large",
    "batch_timeout",
    "internal_error",
}
_SAFE_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
_HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
_ORIGIN_NETLOC_RE = re.compile(r"^(?:\[[^\]]+\]|[^:]+):[0-9]+$")
_DRIVE_RE = re.compile(r"^[A-Za-z]:")


def _redact_message(value: object) -> str:
    """Return a short, single-line provider-safe message."""

    # The result schema excludes C0 controls and DEL.  Normalize all of them
    # before URL/secret redaction so an exception cannot smuggle a tab, escape
    # byte or terminal control sequence into the public envelope or logs.
    text = re.sub(r"[\x00-\x1f\x7f]", " ", str(value))
    text = re.sub(r"(?:https?|ftp)://\S+", "<redacted-url>", text, flags=re.I)
    text = re.sub(r"(?:token|secret|key|password)\s*[=:]\s*\S+", "<redacted>", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:256] or "provider error"


def _log_event(
    code: str,
    *,
    query_index: int | None = None,
    asset_id: str | None = None,
    bytes_count: int | None = None,
    digest: str | None = None,
) -> None:
    """Log only the frozen safe fields (never query, candidate, URL or body)."""

    fields = [f"code={code}"]
    if query_index is not None:
        fields.append(f"queryIndex={query_index}")
    if asset_id:
        fields.append(f"assetId={asset_id[:128]}")
    if bytes_count is not None:
        fields.append(f"bytes={bytes_count}")
    if digest:
        fields.append(f"digestPrefix={digest[:12]}")
    print("[asset3d-search] " + " ".join(fields), file=sys.stderr)


def _safe_int_env(name: str, default: int) -> int:
    try:
        value = int(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def _safe_float_env(name: str, default: float) -> float:
    try:
        value = float(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def _contract_limits() -> dict[str, float | int]:
    """Read test-only knobs while preserving frozen production defaults."""

    return {
        # Lower values are useful for deterministic unit fixtures.  Never let
        # an ambient environment expand a frozen security/deadline budget.
        "max_queries": min(_safe_int_env("ASSET3D_MAX_QUERIES", MAX_QUERIES), MAX_QUERIES),
        "max_redirects": min(_safe_int_env("ASSET3D_MAX_REDIRECTS", MAX_REDIRECTS), MAX_REDIRECTS),
        "search_item": min(
            _safe_float_env("ASSET3D_SEARCH_ITEM_TIMEOUT_SECONDS", SEARCH_ITEM_TIMEOUT_SECONDS),
            SEARCH_ITEM_TIMEOUT_SECONDS,
        ),
        "search_batch": min(
            _safe_float_env("ASSET3D_SEARCH_BATCH_TIMEOUT_SECONDS", SEARCH_BATCH_TIMEOUT_SECONDS),
            SEARCH_BATCH_TIMEOUT_SECONDS,
        ),
        "download_item": min(
            _safe_float_env("ASSET3D_DOWNLOAD_ITEM_TIMEOUT_SECONDS", DOWNLOAD_ITEM_TIMEOUT_SECONDS),
            DOWNLOAD_ITEM_TIMEOUT_SECONDS,
        ),
        "work": min(_safe_float_env("ASSET3D_WORK_DEADLINE_SECONDS", WORK_DEADLINE_SECONDS), WORK_DEADLINE_SECONDS),
        "cleanup": min(_safe_float_env("ASSET3D_CLEANUP_TIMEOUT_SECONDS", CLEANUP_TIMEOUT_SECONDS), CLEANUP_TIMEOUT_SECONDS),
    }


class Deadline:
    __slots__ = ("started", "seconds")

    def __init__(self, started: float, seconds: float) -> None:
        self.started = started
        self.seconds = seconds

    @classmethod
    def start(cls) -> "Deadline":
        return cls(asyncio.get_running_loop().time(), float(_contract_limits()["work"]))

    @property
    def elapsed(self) -> float:
        return max(0.0, asyncio.get_running_loop().time() - self.started)

    @property
    def remaining(self) -> float:
        return max(0.0, self.seconds - self.elapsed)

    def ensure(self) -> None:
        if self.remaining <= 0:
            raise DeadlineExceeded()

    def timeout(self, requested: float) -> float:
        remaining = self.remaining
        if remaining <= 0:
            raise DeadlineExceeded()
        return min(float(requested), remaining)


# ---------------------------------------------------------------------------
# Canonical origin authority
# ---------------------------------------------------------------------------


def _canonical_host(host: str) -> str:
    host = host.strip()
    if not host or "*" in host or any(ch.isspace() for ch in host):
        raise ProviderError("download_origin_rejected", "download origin is not authorized")
    if "%" in host:
        raise ProviderError("download_origin_rejected", "download origin is not authorized")
    try:
        if ":" in host:
            return f"[{ipaddress.IPv6Address(host).compressed}]"
        try:
            return str(ipaddress.IPv4Address(host))
        except ipaddress.AddressValueError:
            ascii_host = host.encode("idna").decode("ascii").lower().rstrip(".")
            if not ascii_host or len(ascii_host) > 253:
                raise ValueError
            labels = ascii_host.split(".")
            if any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-") for label in labels):
                raise ValueError
            if any(not re.fullmatch(r"[a-z0-9-]+", label) for label in labels):
                raise ValueError
            return ascii_host
    except (ValueError, UnicodeError):
        raise ProviderError("download_origin_rejected", "download origin is not authorized") from None


def canonicalize_origin(value: str) -> str:
    """Canonicalize exactly ``scheme://host:port`` and reject all suffixes."""

    if not isinstance(value, str) or not value or any(ch.isspace() for ch in value):
        raise ProviderError("download_origin_rejected", "download origin is not authorized")
    try:
        parsed = urlsplit(value)
        scheme = parsed.scheme.lower()
        if scheme not in {"http", "https"}:
            raise ValueError
        if parsed.username is not None or parsed.password is not None:
            raise ValueError
        if parsed.path or parsed.query or parsed.fragment or not parsed.netloc:
            raise ValueError
        if not _ORIGIN_NETLOC_RE.fullmatch(parsed.netloc):
            raise ValueError
        host = parsed.hostname
        port = parsed.port
        if host is None or port is None or not 1 <= port <= 65535:
            raise ValueError
        return f"{scheme}://{_canonical_host(host)}:{port}"
    except (ValueError, UnicodeError, IndexError):
        raise ProviderError("download_origin_rejected", "download origin is not authorized") from None


def load_authorized_origins(raw: str | None = None) -> tuple[tuple[str, ...], str]:
    """Load only the installed compact JSON origin set and its identity digest."""

    encoded = os.environ.get("AW_DOWNLOAD_ORIGINS", "") if raw is None else raw
    try:
        values = json.loads(encoded)
    except (TypeError, ValueError, json.JSONDecodeError):
        raise ProviderError("download_origin_rejected", "installed download origins are invalid") from None
    if not isinstance(values, list) or not 1 <= len(values) <= 8:
        raise ProviderError("download_origin_rejected", "installed download origins are invalid")
    canonical: list[str] = []
    for value in values:
        canonical.append(canonicalize_origin(value))
    if len(set(canonical)) != len(canonical):
        raise ProviderError("download_origin_rejected", "duplicate download origin")
    ordered = tuple(sorted(canonical))
    compact = json.dumps(list(ordered), ensure_ascii=True, separators=(",", ":"))
    return ordered, hashlib.sha256(compact.encode("utf-8")).hexdigest()


def _origin_receipt(origin_set_digest: str) -> dict[str, str]:
    """Return the privacy-safe, versioned authority receipt for one batch."""

    if not isinstance(origin_set_digest, str) or not _HEX64_RE.fullmatch(origin_set_digest):
        raise ProviderError("internal_error", "origin authority receipt is invalid")
    provider_commit = PROVIDER_COMMIT
    root_value = os.environ.get("ASSET3D_BUNDLE_ROOT", "")
    if root_value:
        try:
            manifest = json.loads((Path(root_value) / "bundle-manifest.json").read_text(encoding="utf-8"))
            candidate = manifest.get("providerCommit") if isinstance(manifest, dict) else None
            if manifest.get("schema") != BUNDLE_SCHEMA_VERSION or not isinstance(candidate, str) or not re.fullmatch(r"[0-9a-f]{40}", candidate):
                raise ValueError
            provider_commit = candidate
        except (OSError, TypeError, ValueError, json.JSONDecodeError):
            raise ProviderError("internal_error", "provider bundle identity is invalid") from None
    return {
        "schemaVersion": RECEIPT_SCHEMA_VERSION,
        "provider": PROVIDER_NAME,
        "providerCommit": provider_commit,
        "originSetDigest": origin_set_digest,
    }


def _url_origin(url: str) -> str:
    try:
        parsed = urlsplit(url)
        scheme = parsed.scheme.lower()
        if scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError
        if parsed.username is not None or parsed.password is not None or parsed.hostname is None:
            raise ValueError
        # Installed authority records always carry an explicit port. Real signed
        # URLs commonly omit a scheme's default port, so normalize 80/443 before
        # exact membership comparison without admitting a wildcard authority.
        port = parsed.port or (443 if scheme == "https" else 80)
        authority = f"{scheme}://{_canonical_host(parsed.hostname)}:{port}"
        return canonicalize_origin(authority)
    except (ValueError, UnicodeError, IndexError, TypeError):
        raise ProviderError("download_origin_rejected", "download origin is not authorized") from None


def _assert_authorized_url(url: str, origins: Iterable[str]) -> None:
    origin = _url_origin(url)
    if origin not in set(origins):
        raise ProviderError("download_origin_rejected", "download origin is not authorized", retryable=True)


# ---------------------------------------------------------------------------
# No-follow quarantine and archive validation
# ---------------------------------------------------------------------------


def _lstat(path: str | os.PathLike[str]) -> os.stat_result:
    return os.lstat(path)


def _directory_open_flags() -> int:
    flags = os.O_RDONLY
    flags |= getattr(os, "O_DIRECTORY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    return flags


def _open_directory(path: str, *, dir_fd: int | None = None) -> int:
    """Open a directory without following the final component."""

    try:
        fd = os.open(path, _directory_open_flags(), dir_fd=dir_fd)
        st = os.fstat(fd)
        if not stat.S_ISDIR(st.st_mode):
            os.close(fd)
            raise ProviderError("archive_rejected", "quarantine path is not a directory")
        return fd
    except ProviderError:
        raise
    except (OSError, TypeError):
        raise ProviderError("archive_rejected", "quarantine path is not a directory") from None


def _relative_directory_fd(root_fd: int, components: Iterable[str], *, mode: int = 0o700) -> int:
    """Walk/create a directory below an already-open root descriptor.

    Every component is opened relative to the descriptor for its parent.  A
    concurrent replacement with a symlink therefore fails closed instead of
    redirecting a later path-based open outside quarantine.
    """

    current = os.dup(root_fd)
    try:
        for component in components:
            try:
                os.mkdir(component, mode, dir_fd=current)
            except FileExistsError:
                pass
            next_fd = _open_directory(component, dir_fd=current)
            os.close(current)
            current = next_fd
        return current
    except BaseException:
        try:
            os.close(current)
        except OSError:
            pass
        raise


def _normalise_unanchored_directory(path: str) -> tuple[str, list[str]]:
    """Split an unanchored path while allowing macOS's /tmp alias only."""

    raw = os.path.abspath(path)
    # On macOS /tmp is an OS-owned symlink to /private/tmp.  Resolve only that
    # known alias; attacker-controlled intermediate components remain lexical
    # and are rejected by descriptor-relative traversal below.
    target = raw
    for os_alias in ("/tmp", "/var"):
        alias = os.path.abspath(os_alias)
        if raw == alias or raw.startswith(alias + os.sep):
            target = os.path.realpath(alias) + raw[len(alias) :]
            break
    drive, tail = os.path.splitdrive(target)
    root = drive + os.sep if tail.startswith(os.sep) else drive
    components = [part for part in tail.split(os.sep) if part]
    return root, components


def _ensure_directory(path: str | os.PathLike[str], *, mode: int = 0o700, root: str | None = None) -> str:
    """Create components without following a symlink below an optional root.

    macOS exposes ``/tmp`` as a symlink to ``/private/tmp``.  For an
    unanchored setup path we normalize that OS-owned ancestor first.  Once a
    quarantine root is known, every component below it is checked with
    ``lstat`` and symlinks are rejected rather than resolved.
    """

    raw_target = os.path.abspath(os.fspath(path))
    if root is None:
        target_root, components = _normalise_unanchored_directory(raw_target)
        target = target_root + os.sep.join(components)
        if target_root.endswith(os.sep) and components:
            target = target_root + os.sep.join(components)
        elif not components:
            target = target_root or raw_target
        root_fd = _open_directory(target_root or os.curdir)
    else:
        # Keep the caller's lexical path below the supplied root while
        # allowing an OS-owned alias above it.  In particular, do not use
        # realpath(raw_target) to walk the suffix: doing so would follow an
        # attacker-controlled intermediate symlink before lstat can reject it.
        raw_root = os.path.abspath(root)
        if os.path.islink(raw_root) or os.path.islink(raw_target):
            raise ProviderError("archive_rejected", "quarantine root is a symlink")
        try:
            if os.path.commonpath([raw_root, raw_target]) != raw_root:
                raise ValueError
        except ValueError:
            raise ProviderError("archive_rejected", "quarantine path escapes its root") from None
        target = raw_target
        root_fd = _open_directory(raw_root)
        relative = os.path.relpath(raw_target, raw_root)
        components = [] if relative == os.curdir else [part for part in relative.split(os.sep) if part]
    try:
        final_fd = _relative_directory_fd(root_fd, components, mode=mode)
        os.close(final_fd)
    finally:
        os.close(root_fd)
    return target


def _assert_contained(path: str, root: str) -> None:
    root_abs = os.path.realpath(os.path.abspath(root))
    path_abs = os.path.realpath(os.path.abspath(path))
    try:
        if os.path.commonpath([root_abs, path_abs]) != root_abs:
            raise ValueError
    except ValueError:
        raise ProviderError("archive_rejected", "quarantine path escapes its root") from None


def _quarantine_root() -> str:
    configured = os.environ.get("MCP_SHARED_PATH", "/workspace")
    if os.path.islink(os.path.abspath(configured)):
        raise ProviderError("archive_rejected", "quarantine root is a symlink")
    _ensure_directory(configured)
    root = os.path.realpath(configured)
    st = _lstat(root)
    if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode):
        raise ProviderError("archive_rejected", "quarantine root is not a directory")
    return root


def _resolve_output_dir(requested: object) -> str:
    """Resolve a caller hint only inside the installed quarantine root."""

    root = _quarantine_root()
    if requested is None or (isinstance(requested, str) and not requested.strip()):
        suffix = "asset3d"
    elif not isinstance(requested, str):
        raise ProviderError("archive_rejected", "output directory is invalid")
    else:
        value = requested.replace("\\", "/").strip()
        if value.startswith("/") or "\x00" in value:
            raise ProviderError("archive_rejected", "output directory is invalid")
        if value.startswith("workspace/"):
            value = value[len("workspace/") :]
        parts = value.rstrip("/").split("/")
        if not value or any(part in {"", ".", ".."} for part in parts):
            raise ProviderError("archive_rejected", "output directory is invalid")
        if parts[0] not in {"asset3d", "games"}:
            raise ProviderError("archive_rejected", "output directory is outside quarantine")
        suffix = "/".join(parts)
    candidate = os.path.abspath(os.path.join(root, suffix))
    _assert_contained(candidate, root)
    _ensure_directory(candidate, root=root)
    return candidate


def _make_asset_dir(output_dir: str, query_index: int, provider_id: str) -> str:
    _ensure_directory(output_dir, root=os.path.realpath(output_dir))
    root_real = os.path.realpath(output_dir)
    root_fd = _open_directory(root_real)
    identity = hashlib.sha256(provider_id.encode("utf-8")).hexdigest()[:16]
    name = f"{query_index:04d}-{identity}"
    candidate = os.path.join(root_real, name)
    try:
        # mkdirat + a no-follow descriptor check closes the classic
        # check-then-create symlink swap between lstat and mkdir. The stable
        # name also keeps package-relative paths and aggregate digests stable
        # across independent transactions for the same selected asset.
        os.mkdir(name, 0o700, dir_fd=root_fd)
        candidate_fd = _open_directory(name, dir_fd=root_fd)
        os.close(candidate_fd)
        _assert_contained(candidate, root_real)
        return candidate
    except FileExistsError:
        raise ProviderError("internal_error", "asset output already exists", retryable=True) from None
    finally:
        os.close(root_fd)


def _safe_relative_member(name: str, *, directory: bool = False) -> str:
    if not isinstance(name, str) or not name or "\x00" in name or "\\" in name:
        raise ProviderError("archive_rejected", "archive member path is invalid")
    if directory and name.endswith("/"):
        name = name[:-1]
    if not name or name.startswith("/") or _DRIVE_RE.match(name):
        raise ProviderError("archive_rejected", "archive member path is invalid")
    parts = name.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ProviderError("archive_rejected", "archive member path is invalid")
    normalized = posixpath.normpath(name)
    if normalized != name or normalized.startswith("../") or normalized == "..":
        raise ProviderError("archive_rejected", "archive member path is invalid")
    return name


def _member_kind(info: zipfile.ZipInfo) -> str:
    mode = (info.external_attr >> 16) & 0xFFFF
    file_type = stat.S_IFMT(mode)
    if info.flag_bits & 0x1:
        raise ProviderError("archive_rejected", "encrypted archive member is not allowed")
    if file_type == stat.S_IFLNK:
        raise ProviderError("archive_rejected", "archive links are not allowed")
    if file_type in {stat.S_IFCHR, stat.S_IFBLK, stat.S_IFIFO, stat.S_IFSOCK}:
        raise ProviderError("archive_rejected", "archive special file is not allowed")
    if info.is_dir() or file_type == stat.S_IFDIR:
        return "directory"
    if file_type not in {0, stat.S_IFREG}:
        raise ProviderError("archive_rejected", "archive member type is not allowed")
    return "file"


def _open_new_file(path: str, *, dir_fd: int | None = None) -> int:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    return os.open(path, flags, 0o600, dir_fd=dir_fd)


def _open_quarantine_file(path: str, root: str) -> tuple[int, int, str]:
    """Open a new output file through a descriptor-relative quarantine walk."""

    root_abs = os.path.realpath(os.path.abspath(root))
    path_abs = os.path.abspath(path)
    try:
        relative = os.path.relpath(path_abs, root_abs)
    except ValueError:
        raise ProviderError("archive_rejected", "quarantine path escapes its root") from None
    components = relative.split(os.sep)
    if not components or any(part in {"", ".", ".."} for part in components):
        raise ProviderError("archive_rejected", "quarantine path is invalid")
    root_fd = _open_directory(root_abs)
    parent_fd: int | None = None
    try:
        parent_fd = _relative_directory_fd(root_fd, components[:-1])
        fd = _open_new_file(components[-1], dir_fd=parent_fd)
        return fd, parent_fd, components[-1]
    except BaseException:
        if parent_fd is not None:
            os.close(parent_fd)
        raise
    finally:
        os.close(root_fd)


def _safe_extract_zip(zip_path: str, target_dir: str, *, deadline_at: float | None = None) -> None:
    """Extract a ZIP with path/type/size/ratio/CRC and no-follow checks."""

    if deadline_at is not None and time.monotonic() >= deadline_at:
        raise DeadlineExceeded()
    _ensure_directory(target_dir, root=os.path.dirname(os.path.abspath(target_dir)))
    _assert_contained(zip_path, os.path.dirname(os.path.realpath(target_dir)))
    expanded = 0
    names: set[str] = set()
    folded: set[str] = set()
    target_fd = _open_directory(os.path.abspath(target_dir))
    archive_fd: int | None = None
    try:
        # The archive is normally a provider-created child of target_dir.  A
        # no-follow descriptor check also prevents a caller or race from
        # substituting a symlink before ZipFile opens it.
        archive_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        archive_fd = os.open(zip_path, archive_flags)
        if os.fstat(archive_fd).st_size > MAX_DOWNLOAD_BYTES:
            raise ProviderError("archive_rejected", "archive size exceeds limit")
        with os.fdopen(archive_fd, "rb") as archive_stream:
            archive_fd = None
            with zipfile.ZipFile(archive_stream, "r") as archive:
                infos = archive.infolist()
                if len(infos) > MAX_ARCHIVE_MEMBERS:
                    raise ProviderError("archive_rejected", "archive member limit exceeded")
                for info in infos:
                    if deadline_at is not None and time.monotonic() >= deadline_at:
                        raise DeadlineExceeded()
                    kind = _member_kind(info)
                    name = _safe_relative_member(info.filename, directory=kind == "directory")
                    folded_name = name.casefold()
                    if name in names or folded_name in folded:
                        raise ProviderError("archive_rejected", "archive duplicate member")
                    names.add(name)
                    folded.add(folded_name)
                    if kind == "directory":
                        directory_fd = _relative_directory_fd(target_fd, name.split("/"))
                        os.close(directory_fd)
                        continue
                    compressed = int(info.compress_size)
                    uncompressed = int(info.file_size)
                    if uncompressed < 0 or uncompressed > MAX_FILE_BYTES:
                        raise ProviderError("archive_rejected", "archive file limit exceeded")
                    if compressed == 0 and uncompressed:
                        raise ProviderError("archive_rejected", "archive expansion ratio exceeded")
                    if compressed and uncompressed > compressed * MAX_EXPANSION_RATIO:
                        raise ProviderError("archive_rejected", "archive expansion ratio exceeded")
                    expanded += uncompressed
                    if expanded > MAX_ARCHIVE_EXPANDED_BYTES:
                        raise ProviderError("archive_rejected", "archive expanded size exceeded")
                    parent_fd = _relative_directory_fd(target_fd, name.split("/")[:-1])
                    try:
                        fd = _open_new_file(name.split("/")[-1], dir_fd=parent_fd)
                    except FileExistsError:
                        raise ProviderError("archive_rejected", "archive destination collision") from None
                    finally:
                        os.close(parent_fd)
                    count = 0
                    try:
                        with archive.open(info, "r") as source:
                            while True:
                                if deadline_at is not None and time.monotonic() >= deadline_at:
                                    raise DeadlineExceeded()
                                chunk = source.read(1024 * 1024)
                                if not chunk:
                                    break
                                count += len(chunk)
                                if count > MAX_FILE_BYTES:
                                    raise ProviderError("archive_rejected", "archive file limit exceeded")
                                pending = memoryview(chunk)
                                while pending:
                                    written = os.write(fd, pending)
                                    if written <= 0:
                                        raise OSError("short archive write")
                                    pending = pending[written:]
                        if count != uncompressed:
                            raise ProviderError("archive_rejected", "archive member is truncated")
                        os.fsync(fd)
                    finally:
                        os.close(fd)
    except ProviderError:
        raise
    except (zipfile.BadZipFile, EOFError, OSError, RuntimeError) as exc:
        raise ProviderError("archive_rejected", "archive validation failed") from exc
    finally:
        if archive_fd is not None:
            try:
                os.close(archive_fd)
            except OSError:
                pass
        try:
            os.close(target_fd)
        except OSError:
            pass


def _cleanup_sync(path: str) -> None:
    if not path:
        return
    try:
        st = _lstat(path)
    except FileNotFoundError:
        return
    if stat.S_ISLNK(st.st_mode):
        os.unlink(path)
        return
    if stat.S_ISDIR(st.st_mode):
        shutil.rmtree(path)
    else:
        os.unlink(path)


async def _bounded_cleanup(path: str) -> None:
    timeout = float(_contract_limits()["cleanup"])
    try:
        await asyncio.wait_for(asyncio.to_thread(_cleanup_sync, path), timeout=timeout)
    except (asyncio.TimeoutError, FileNotFoundError, ProviderError):
        return


async def _await_blocking(
    operation: Any,
    *args: Any,
    deadline: Deadline | None,
    timeout: float,
    timeout_code: str,
    timeout_message: str,
    operation_kwargs: dict[str, Any] | None = None,
) -> Any:
    """Run bounded filesystem/converter work without blocking the event loop."""

    timeout_value = deadline.timeout(timeout) if deadline is not None else timeout
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(operation, *args, **(operation_kwargs or {})),
            timeout=timeout_value,
        )
    except ProviderError:
        raise
    except asyncio.TimeoutError:
        if deadline is not None and deadline.remaining <= 0:
            raise DeadlineExceeded() from None
        raise ProviderError(timeout_code, timeout_message, retryable=True) from None


# ---------------------------------------------------------------------------
# AW search and optional ranking
# ---------------------------------------------------------------------------


def _api_error(code: str, message: str, *, retryable: bool = False) -> dict[str, Any]:
    return {"assets": [], "error": ProviderError(code, message, retryable=retryable)}


def _catalog_tokens(value: object) -> list[str]:
    return re.findall(r"[a-z0-9]+|[\u3400-\u9fff]+", str(value).lower())


def _catalog_candidate(record: dict[str, Any], query_tokens: list[str]) -> tuple[int, dict[str, Any]] | None:
    provider_id = record.get("id")
    if not isinstance(provider_id, str) or not _SAFE_ID_RE.fullmatch(provider_id):
        return None
    tags = record.get("tags") if isinstance(record.get("tags"), dict) else {}
    caption = str(tags.get("caption", ""))
    fields = [
        provider_id,
        record.get("assetName", ""),
        record.get("type", ""),
        tags.get("art_style", ""),
        tags.get("theme_style", ""),
        tags.get("game_category", ""),
        tags.get("category", ""),
        caption,
    ]
    haystack = " ".join(json.dumps(value, ensure_ascii=False) if isinstance(value, list) else str(value) for value in fields).lower()
    matched = [token for token in query_tokens if token in haystack]
    if not matched:
        return None
    exact_caption = sum(1 for token in matched if token in caption.lower())
    exact_identity = query_tokens in (
        _catalog_tokens(provider_id),
        _catalog_tokens(record.get("assetName", "")),
    )
    score = len(matched) * 100 + exact_caption * 20 + (10_000 if exact_identity else 0)
    file_name = str(record.get("file", ""))
    suffix = Path(file_name).suffix.lower().lstrip(".")
    normalized_tags = [
        str(value)
        for key in ("art_style", "theme_style", "category")
        for value in ([tags.get(key)] if tags.get(key) else [])
    ]
    game_categories = tags.get("game_category")
    if isinstance(game_categories, list):
        normalized_tags.extend(str(value) for value in game_categories if value)
    candidate = {
        "id": provider_id,
        "name": str(record.get("assetName") or provider_id),
        "description": caption,
        "tags": normalized_tags,
        "type": str(record.get("type", "")),
        "file_format": suffix or "glb",
        "_download_url": f"{ASSET3D_CATALOG_BASE_URL}/api/download/assets",
        "_download_method": "catalog-post",
    }
    return score, candidate


async def catalog_search(session: Any, content: str, page_size: int = 10, *, deadline: Deadline | None = None) -> dict[str, Any]:
    """Search the explicitly configured bounded catalog without exposing it."""

    if aiohttp is None or not ASSET3D_CATALOG_BASE_URL:
        return _api_error("search_upstream_error", "catalog search is unavailable", retryable=True)
    try:
        origins, _digest = load_authorized_origins()
        search_url = f"{ASSET3D_CATALOG_BASE_URL}/api/search"
        catalog_url = f"{ASSET3D_CATALOG_BASE_URL}/api/assets"
        _assert_authorized_url(search_url, origins)
        _assert_authorized_url(catalog_url, origins)
        timeout_value = deadline.timeout(AW_API_TIMEOUT) if deadline is not None else AW_API_TIMEOUT
        timeout = aiohttp.ClientTimeout(total=timeout_value)
        async with session.post(
            search_url,
            json={"query": content, "limit": page_size},
            timeout=timeout,
            allow_redirects=False,
        ) as response:
            status = int(response.status)
            if status == 200:
                raw = await response.read()
            elif status in {404, 405}:
                raw = b""
            else:
                return _api_error("search_upstream_error", "catalog search returned an error", retryable=True)
        if not raw:
            async with session.get(catalog_url, timeout=timeout, allow_redirects=False) as response:
                if int(response.status) != 200:
                    return _api_error("search_upstream_error", "catalog fallback returned an error", retryable=True)
                raw = await response.read()
        if not raw or len(raw) > MAX_CATALOG_BYTES:
            return _api_error("search_upstream_error", "catalog response exceeds limit", retryable=True)
        data = json.loads(raw)
        values = data if isinstance(data, list) else data.get("assets", []) if isinstance(data, dict) else []
        if not isinstance(values, list) or len(values) > MAX_CATALOG_RECORDS:
            return _api_error("search_upstream_error", "catalog response is invalid", retryable=True)
        query_tokens = _catalog_tokens(content)
        ranked = [row for record in values if isinstance(record, dict) if (row := _catalog_candidate(record, query_tokens)) is not None]
        ranked.sort(key=lambda row: (-row[0], str(row[1]["id"]).encode("utf-8")))
        return {"assets": [row[1] for row in ranked[:page_size]], "error": None}
    except (asyncio.TimeoutError, TimeoutError):
        return _api_error("search_timeout", "catalog search timed out", retryable=True)
    except ProviderError as exc:
        return {"assets": [], "error": exc}
    except Exception:
        return _api_error("search_upstream_error", "catalog search is unavailable", retryable=True)


_AW_SERVICE_PATH = "/trpc.oasismetric.omcontentserver.http"
_AW_CREDENTIAL_SCHEMA = "forgeax.asset3d-credential/1.0.0"
_MAX_CREDENTIAL_BYTES = 4096


def _aw_hybrid_search_url(base_url: str) -> str:
    """Normalize either a gateway base or the documented AW service root."""

    try:
        parsed = urlsplit(base_url.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError
        if parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment:
            raise ValueError
        path = parsed.path.rstrip("/")
        if path.endswith(f"{_AW_SERVICE_PATH}/HybridSearch"):
            path = path[: -len("/HybridSearch")]
        elif not path.endswith(_AW_SERVICE_PATH):
            path = f"{path}{_AW_SERVICE_PATH}"
        return parsed._replace(path=f"{path}/HybridSearch", query="", fragment="").geturl()
    except (AttributeError, TypeError, ValueError):
        raise ProviderError("search_upstream_error", "search service configuration is invalid") from None


def _load_aw_sandbox_key() -> str:
    """Read an AW key without copying it into project MCP configuration."""

    if AW_API_SANDBOX_KEY:
        return AW_API_SANDBOX_KEY
    if not AW_API_CREDENTIAL_FILE:
        return ""
    try:
        path = Path(AW_API_CREDENTIAL_FILE)
        if not path.is_absolute():
            raise ValueError
        metadata = path.lstat()
        if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
            raise ValueError
        if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
            raise ValueError
        if stat.S_IMODE(metadata.st_mode) & 0o077 or not 0 < metadata.st_size <= _MAX_CREDENTIAL_BYTES:
            raise ValueError
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or set(value) != {"schemaVersion", "provider", "sandboxKey"}:
            raise ValueError
        key = value.get("sandboxKey")
        if (
            value.get("schemaVersion") != _AW_CREDENTIAL_SCHEMA
            or value.get("provider") != "aw"
            or not isinstance(key, str)
            or not key
            or len(key) > 2048
            or any(ord(character) < 0x20 or ord(character) == 0x7F for character in key)
        ):
            raise ValueError
        return key
    except (OSError, UnicodeError, TypeError, ValueError, json.JSONDecodeError):
        raise ProviderError("search_upstream_error", "search credentials are unavailable") from None


def _download_origin_from_url(value: object) -> str:
    try:
        if not isinstance(value, str):
            raise ValueError
        parsed = urlsplit(value)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError
        if parsed.username is not None or parsed.password is not None or parsed.hostname is None:
            raise ValueError
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        return canonicalize_origin(f"{parsed.scheme}://{_canonical_host(parsed.hostname)}:{port}")
    except (ProviderError, TypeError, ValueError):
        raise ProviderError("search_upstream_error", "search response is invalid") from None


async def aw_search(session: Any, content: str, page_size: int = 10, *, deadline: Deadline | None = None) -> dict[str, Any]:
    """Search AW without exposing request URL, body, candidate or response."""

    if ASSET3D_CATALOG_BASE_URL:
        return await catalog_search(session, content, page_size=page_size, deadline=deadline)
    if aiohttp is None:
        return _api_error("search_upstream_error", "search dependency unavailable", retryable=True)
    if not AW_API_BASE_URL:
        return _api_error("search_upstream_error", "search service unavailable", retryable=True)
    try:
        sandbox_key = _load_aw_sandbox_key()
        url = _aw_hybrid_search_url(AW_API_BASE_URL)
    except ProviderError as exc:
        return {"assets": [], "error": exc}
    if not sandbox_key:
        return _api_error("search_upstream_error", "search credentials unavailable", retryable=True)
    headers = {"Content-Type": "application/json", "X-Sandbox-Key": sandbox_key}
    payload = {
        "depot_name": AW_API_DEPOT_NAME,
        "asset_type": 1,
        "req_content_type": 0,
        "content": content,
        "similarity_score": 0.0,
        "page_size": page_size,
    }
    timeout_value = AW_API_TIMEOUT if deadline is None else deadline.timeout(AW_API_TIMEOUT)
    try:
        timeout = aiohttp.ClientTimeout(total=timeout_value)
        async with session.post(
            url,
            json=payload,
            headers=headers,
            timeout=timeout,
            allow_redirects=False,
        ) as response:
            if response.status != 200:
                return _api_error("search_upstream_error", "search service returned an error", retryable=True)
            try:
                data = await response.json(content_type=None)
            except TypeError:
                data = await response.json()
        if not isinstance(data, dict):
            return _api_error("search_upstream_error", "search response is invalid", retryable=True)
        if data.get("ret") not in (None, 0):
            return _api_error("search_upstream_error", "search service returned an error", retryable=True)
        assets: list[dict[str, Any]] = []
        values = data.get("asset_list", [])
        for item in values if isinstance(values, list) else []:
            if isinstance(item, dict):
                copied = dict(item)
                copied["_download_url"] = item.get("res_url")
                assets.append(copied)
        return {"assets": assets, "error": None}
    except (asyncio.TimeoutError, TimeoutError):
        return _api_error("search_timeout", "search service timed out", retryable=True)
    except ProviderError as exc:
        return {"assets": [], "error": exc}
    except Exception:
        return _api_error("search_upstream_error", "search service unavailable", retryable=True)


async def check_aw_access() -> dict[str, Any]:
    """Validate AW access and disclose only origins needed by the download sandbox."""

    async with _client_session() as session:
        result = await aw_search(session, "tree", page_size=3)
    if result.get("error") is not None:
        return {
            "schemaVersion": "forgeax.asset3d-access-check/1.0.0",
            "ok": False,
            "error": {"code": "asset3d_api_key_invalid_or_unavailable"},
        }
    try:
        origins = sorted(
            {
                _download_origin_from_url(asset.get("_download_url"))
                for asset in result.get("assets", [])
                if isinstance(asset, dict)
            }
        )
    except ProviderError:
        origins = []
    if not origins or len(origins) > 8:
        return {
            "schemaVersion": "forgeax.asset3d-access-check/1.0.0",
            "ok": False,
            "error": {"code": "asset3d_access_validation_inconclusive"},
        }
    return {
        "schemaVersion": "forgeax.asset3d-access-check/1.0.0",
        "ok": True,
        "value": {"authentication": "sandbox-key", "downloadOrigins": origins},
    }


_ASSET_PICK_SYSTEM = (
    "You are a game asset selection expert. Given a numbered list of candidate "
    "assets, reply with only the number of the best match or 0."
)


def _format_candidates(assets: list[dict[str, Any]]) -> str:
    lines = []
    for index, asset in enumerate(assets, 1):
        # This string is sent privately to the LLM; it is never logged or
        # copied into a result.  Keep the historical ranking behavior.
        name = str(asset.get("name", "unknown"))
        description = str(asset.get("description", ""))
        tags = ", ".join(str(tag) for tag in asset.get("tags", []) if tag)
        line = f"[{index}] {name}"
        if description:
            line += f" Description: {description}"
        if tags:
            line += f" Tags: {tags}"
        lines.append(line)
    return "\n\n".join(lines)


def _build_llm_messages(query: str, candidates_text: str) -> list[dict[str, str]]:
    return [
        {
            "role": "user",
            "content": f"{_ASSET_PICK_SYSTEM}\n\nUser query: {query}\n\nCandidates:\n{candidates_text}",
        }
    ]


async def _llm_vote_once_attempt(session: Any, query: str, candidates_text: str) -> tuple[int | None, str]:
    if aiohttp is None or os.environ.get("ASSET3D_DISABLE_LLM") == "1":
        return None, "exception"
    url = f"{os.environ.get('LLM_BASE_URL', 'http://127.0.0.1:9000/v1/out/llm').rstrip('/')}/v1/messages"
    payload = {
        "model": "ignore",
        "max_tokens": 32,
        "stop": ["\n", ".", ",", ":", ";"],
        "messages": _build_llm_messages(query, candidates_text),
    }
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with session.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json", "X-User-ID": LLM_USER_ID},
            timeout=timeout,
            allow_redirects=False,
        ) as response:
            if response.status != 200:
                return None, "http_error"
            try:
                data = await response.json(content_type=None)
            except TypeError:
                data = await response.json()
        values = data.get("content", []) if isinstance(data, dict) else []
        text = str(values[0].get("text", "")).strip() if values and isinstance(values[0], dict) else ""
        if text.isdigit():
            return int(text), "ok"
        match = re.match(r"^\d+", text)
        if match:
            return int(match.group()), "ok"
        return None, "empty" if not text else "non_numeric"
    except (asyncio.TimeoutError, TimeoutError):
        return None, "exception"
    except Exception:
        return None, "exception"


async def _llm_vote_once(session: Any, query: str, candidates_text: str) -> int | None:
    result, outcome = await _llm_vote_once_attempt(session, query, candidates_text)
    if result is not None:
        return result
    if outcome in {"empty", "non_numeric", "exception"}:
        result, _ = await _llm_vote_once_attempt(session, query, candidates_text)
        return result
    return None


async def _llm_pick_best(session: Any, query: str, assets: list[dict[str, Any]]) -> dict[str, Any]:
    if len(assets) == 1 or os.environ.get("ASSET3D_DISABLE_LLM") == "1":
        return {"index": 0, "asset": assets[0]}
    candidate_text = _format_candidates(assets)
    raw = await asyncio.gather(
        *[_llm_vote_once(session, query, candidate_text) for _ in range(LLM_VOTE_ROUNDS)],
        return_exceptions=True,
    )
    n = len(assets)
    votes = [value for value in raw if isinstance(value, int) and 0 <= value <= n]
    if not votes:
        return {"index": 0, "asset": assets[0], "fallback_reason": "invalid_vote"}
    winner, count = Counter(votes).most_common(1)[0]
    if winner == 0 or count < 2:
        return {"index": 0, "asset": assets[0], "fallback_reason": "no_consensus"}
    return {"index": winner - 1, "asset": assets[winner - 1]}


def _asset_id(asset: dict[str, Any]) -> str:
    value = asset.get("id")
    if not isinstance(value, str) or not _SAFE_ID_RE.fullmatch(value) or value in {".", ".."}:
        raise ProviderError("asset_identity_missing", "asset identity is missing")
    return value


def _asset_name(asset: dict[str, Any]) -> str:
    raw = str(asset.get("name", "asset"))
    base = Path(raw).name.strip()
    base = re.sub(r"[\\/:*?\"<>|\x00]", "_", base)
    base = re.sub(r"\s+", "_", base).strip("_.")
    return (base or "asset")[:128]


def _guess_ext(asset: dict[str, Any], download_url: str) -> str:
    value = str(asset.get("file_format") or asset.get("format") or "").lower().lstrip(".")
    if value:
        return value
    path = urlsplit(download_url).path
    if "." in path:
        return path.rsplit(".", 1)[-1].lower()
    return "glb"


def _query_content(query: object) -> str:
    if isinstance(query, str):
        return query.strip()
    if isinstance(query, dict):
        value = query.get("content") or query.get("keyword") or ""
        return value.strip() if isinstance(value, str) else ""
    return ""


async def _search_one(session: Any, query: object, *, deadline: Deadline | None = None) -> dict[str, Any]:
    content = _query_content(query)
    if not content:
        raise ProviderError("internal_error", "query is invalid")
    if len(content) > 200:
        raise ProviderError("internal_error", "query is too long")
    result = await aw_search(session, content, page_size=10, deadline=deadline)
    if result.get("error"):
        error = result["error"]
        if isinstance(error, ProviderError):
            raise error
        raise ProviderError("search_upstream_error", "search service unavailable", retryable=True)
    assets = result.get("assets", [])
    if not assets:
        raise ProviderError("asset_not_found", "asset was not found")
    pick = await _llm_pick_best(session, content, assets)
    chosen = pick.get("asset")
    if not isinstance(chosen, dict):
        raise ProviderError("asset_not_found", "asset was not found")
    provider_id = _asset_id(chosen)
    download_url = chosen.get("_download_url")
    if not isinstance(download_url, str) or not download_url:
        raise ProviderError("search_upstream_error", "asset download is unavailable", retryable=True)
    return {
        "content": content,
        "asset": chosen,
        "providerAssetId": provider_id,
        "download_url": download_url,
    }


# ---------------------------------------------------------------------------
# Download, conversion and result manifest
# ---------------------------------------------------------------------------


def _get_proxies() -> dict[str, str]:
    # Proxy values are used by the HTTP client but are never emitted.
    values: dict[str, str] = {}
    http = os.environ.get("http_proxy") or os.environ.get("HTTP_PROXY")
    https = os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY")
    if http:
        values["http"] = http
    if https:
        values["https"] = https
    return values


def _display_path(path: str) -> str:
    """Return a relative, non-authoritative path for legacy display fields."""

    converted = to_external_path(path)
    if not isinstance(converted, str) or os.path.isabs(converted):
        # Tests and embedded callers may override MCP_SHARED_PATH after the
        # shared utility module was imported.  Never let that turn an internal
        # absolute path into public provider output; the field is display-only.
        try:
            root = _quarantine_root()
            relative = os.path.relpath(path, root).replace(os.sep, "/")
            if relative != ".." and not relative.startswith("../"):
                converted = "workspace/" + relative
            else:
                converted = "workspace/asset3d/" + Path(path).name
        except Exception:
            converted = "workspace/asset3d/" + Path(path).name
    value = converted.replace("\\", "/")
    if value.startswith("/") or "\x00" in value or "//" in value or any(part in {"", ".", ".."} for part in value.split("/")):
        return "workspace/asset3d/" + re.sub(r"[^A-Za-z0-9._-]", "_", Path(path).name)[:128]
    return value[:512] or "workspace/asset3d"


async def download_file(
    session: Any,
    url: str,
    output_path: str,
    *,
    authorized_origins: Iterable[str] | None = None,
    deadline: Deadline | None = None,
) -> None:
    """Download one URL with exact origin/redirect and byte limits."""

    origins, _digest = load_authorized_origins() if authorized_origins is None else (tuple(authorized_origins), "")
    _assert_authorized_url(url, origins)
    quarantine = _quarantine_root()
    parent = os.path.dirname(output_path)
    _ensure_directory(parent, root=quarantine)
    _assert_contained(output_path, quarantine)
    current = url
    limits = _contract_limits()
    redirects = int(limits["max_redirects"])
    for hop in range(redirects + 1):
        _assert_authorized_url(current, origins)
        if deadline is not None:
            timeout_value = deadline.timeout(DOWNLOAD_ITEM_TIMEOUT_SECONDS)
        else:
            timeout_value = DOWNLOAD_ITEM_TIMEOUT_SECONDS
        try:
            if aiohttp is None:
                raise ProviderError("download_timeout", "download dependency unavailable", retryable=True)
            timeout = aiohttp.ClientTimeout(total=timeout_value)
            proxy_values = _get_proxies()
            proxy = proxy_values.get("https" if current.lower().startswith("https:") else "http")
            try:
                request = session.get(
                    current,
                    timeout=timeout,
                    proxy=proxy,
                    allow_redirects=False,
                )
            except TypeError:
                request = session.get(current, timeout=timeout, allow_redirects=False)
            async with request as response:
                status = int(response.status)
                if 300 <= status < 400:
                    location = response.headers.get("Location") if getattr(response, "headers", None) else None
                    if not location or hop >= redirects:
                        raise ProviderError("download_origin_rejected", "download redirect is not authorized", retryable=True)
                    current = urljoin(current, str(location))
                    _assert_authorized_url(current, origins)
                    continue
                if status != 200:
                    raise ProviderError("download_timeout", "download service returned an error", retryable=True)
                content_length = None
                if getattr(response, "headers", None):
                    raw_length = response.headers.get("Content-Length")
                    try:
                        content_length = int(raw_length) if raw_length is not None else None
                    except (TypeError, ValueError):
                        content_length = None
                if content_length is not None and content_length > MAX_DOWNLOAD_BYTES:
                    raise ProviderError("download_too_large", "download size exceeds limit")
                fd, parent_fd, leaf_name = _open_quarantine_file(output_path, quarantine)
                count = 0
                try:
                    content = getattr(response, "content", None)
                    if content is not None and hasattr(content, "iter_chunked"):
                        async for chunk in content.iter_chunked(1024 * 1024):
                            if deadline is not None:
                                deadline.ensure()
                            count += len(chunk)
                            if count > MAX_DOWNLOAD_BYTES:
                                raise ProviderError("download_too_large", "download size exceeds limit")
                            os.write(fd, chunk)
                    else:
                        chunk = await response.read()
                        count = len(chunk)
                        if count > MAX_DOWNLOAD_BYTES:
                            raise ProviderError("download_too_large", "download size exceeds limit")
                        os.write(fd, chunk)
                    os.fsync(fd)
                except BaseException:
                    # Never leave a partial download for a retry or a later
                    # caller to mistake for a completed asset.
                    try:
                        os.unlink(leaf_name, dir_fd=parent_fd)
                    except FileNotFoundError:
                        pass
                    raise
                finally:
                    os.close(fd)
                    os.close(parent_fd)
                if count <= 0:
                    raise ProviderError("download_too_large", "download is empty")
                return
        except ProviderError:
            raise
        except (asyncio.TimeoutError, TimeoutError):
            raise ProviderError("download_timeout", "download timed out", retryable=True) from None
        except Exception:
            raise ProviderError("download_timeout", "download failed", retryable=True) from None
    raise ProviderError("download_origin_rejected", "download redirect is not authorized", retryable=True)


async def download_catalog_asset(
    session: Any,
    url: str,
    provider_id: str,
    output_path: str,
    *,
    authorized_origins: Iterable[str],
    deadline: Deadline | None = None,
) -> None:
    """Download one selected catalog id through the provider-owned POST route."""

    origins = tuple(authorized_origins)
    _assert_authorized_url(url, origins)
    quarantine = _quarantine_root()
    _ensure_directory(os.path.dirname(output_path), root=quarantine)
    _assert_contained(output_path, quarantine)
    timeout_value = deadline.timeout(DOWNLOAD_ITEM_TIMEOUT_SECONDS) if deadline is not None else DOWNLOAD_ITEM_TIMEOUT_SECONDS
    try:
        timeout = aiohttp.ClientTimeout(total=timeout_value)
        async with session.post(
            url,
            json={"ids": [provider_id]},
            timeout=timeout,
            allow_redirects=False,
        ) as response:
            if int(response.status) != 200:
                raise ProviderError("download_timeout", "download service returned an error", retryable=True)
            raw_length = response.headers.get("Content-Length") if getattr(response, "headers", None) else None
            try:
                content_length = int(raw_length) if raw_length is not None else None
            except (TypeError, ValueError):
                content_length = None
            if content_length is not None and content_length > MAX_DOWNLOAD_BYTES:
                raise ProviderError("download_too_large", "download size exceeds limit")
            fd, parent_fd, leaf_name = _open_quarantine_file(output_path, quarantine)
            count = 0
            try:
                async for chunk in response.content.iter_chunked(1024 * 1024):
                    if deadline is not None:
                        deadline.ensure()
                    count += len(chunk)
                    if count > MAX_DOWNLOAD_BYTES:
                        raise ProviderError("download_too_large", "download size exceeds limit")
                    os.write(fd, chunk)
                os.fsync(fd)
            except BaseException:
                try:
                    os.unlink(leaf_name, dir_fd=parent_fd)
                except FileNotFoundError:
                    pass
                raise
            finally:
                os.close(fd)
                os.close(parent_fd)
            if count <= 0:
                raise ProviderError("download_too_large", "download is empty")
    except ProviderError:
        raise
    except (asyncio.TimeoutError, TimeoutError):
        raise ProviderError("download_timeout", "download timed out", retryable=True) from None
    except Exception:
        raise ProviderError("download_timeout", "download failed", retryable=True) from None


def _managed_converter_path() -> str:
    """Resolve only the manifest-bound converter injected by the bundle launcher."""

    root_value = os.environ.get("ASSET3D_BUNDLE_ROOT", "")
    injected = os.environ.get("FBX2GLTF_BIN", "")
    if not root_value or not os.path.isabs(root_value):
        raise ProviderError("conversion_failed", "managed GLB converter is unavailable")
    root = Path(root_value)
    manifest_path = root / "bundle-manifest.json"
    converter_path = root / "bin/FBX2glTF"
    if injected != str(converter_path):
        raise ProviderError("conversion_failed", "managed GLB converter identity is invalid")
    try:
        if stat.S_ISLNK(os.lstat(root).st_mode):
            raise ValueError
        manifest_stat = os.lstat(manifest_path)
        converter_stat = os.lstat(converter_path)
        if not stat.S_ISREG(manifest_stat.st_mode) or not stat.S_ISREG(converter_stat.st_mode):
            raise ValueError
        if stat.S_ISLNK(manifest_stat.st_mode) or stat.S_ISLNK(converter_stat.st_mode):
            raise ValueError
        if not os.access(converter_path, os.X_OK):
            raise ValueError
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        converter = manifest.get("converter") if isinstance(manifest, dict) else None
        if (
            manifest.get("schema") != BUNDLE_SCHEMA_VERSION
            or not isinstance(converter, dict)
            or converter.get("path") != "bin/FBX2glTF"
            or not isinstance(converter.get("sha256"), str)
            or not _HEX64_RE.fullmatch(converter["sha256"])
        ):
            raise ValueError
        digest = hashlib.sha256()
        with converter_path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        if digest.hexdigest() != converter["sha256"]:
            raise ValueError
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        raise ProviderError("conversion_failed", "managed GLB converter identity is invalid") from None
    return str(converter_path)


def convert_fbx_to_glb(src_path: str, dst_path: str) -> None:
    """Convert FBX to GLB with the managed, checksum-verified converter."""

    binary = _managed_converter_path()
    try:
        proc = subprocess.run(
            [binary, "--binary", "--input", src_path, "--output", dst_path],
            capture_output=True,
            text=True,
            timeout=DOWNLOAD_ITEM_TIMEOUT_SECONDS,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        raise ProviderError("conversion_failed", "GLB conversion failed") from None
    if not os.path.exists(dst_path):
        appended = dst_path + ".glb"
        if os.path.exists(appended):
            os.replace(appended, dst_path)
    if proc.returncode != 0 or not os.path.isfile(dst_path) or os.path.getsize(dst_path) <= 0:
        raise ProviderError("conversion_failed", "GLB conversion failed")


def convert_package_dir(
    asset_dir: str,
    fmt: str,
    convert_fn=convert_fbx_to_glb,
    *,
    deadline_at: float | None = None,
) -> list[str]:
    """Convert all FBX members; preserve old helper's per-file error list."""

    if fmt != "glb":
        return []
    errors: list[str] = []
    for root, dirs, files in os.walk(asset_dir, topdown=True, followlinks=False):
        if deadline_at is not None and time.monotonic() >= deadline_at:
            raise DeadlineExceeded()
        for directory in list(dirs):
            full = os.path.join(root, directory)
            if os.path.islink(full):
                errors.append(f"{directory}: unsafe symlink")
                dirs.remove(directory)
        for name in sorted(files):
            if deadline_at is not None and time.monotonic() >= deadline_at:
                raise DeadlineExceeded()
            if not name.lower().endswith(".fbx"):
                continue
            src = os.path.join(root, name)
            dst = os.path.join(root, name[:-4] + ".glb")
            try:
                convert_fn(src, dst)
                os.unlink(src)
            except Exception:
                errors.append(f"{name}: GLB conversion failed")
    return errors


def _validate_glb_header(path: str) -> None:
    try:
        size = os.path.getsize(path)
        if size < 12 or size > MAX_GLB_BYTES:
            raise ValueError
        with open(path, "rb") as handle:
            header = handle.read(12)
        if header[:4] != b"glTF" or int.from_bytes(header[4:8], "little") != 2:
            raise ValueError
        declared = int.from_bytes(header[8:12], "little")
        if declared != size or declared < 12:
            raise ValueError
    except (OSError, ValueError):
        raise ProviderError("digest_failed", "GLB header is invalid") from None


_GLB_JSON_CHUNK = 0x4E4F534A
_GLB_BIN_CHUNK = 0x004E4942
_GLTF_COMPONENT_BYTES = {5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4}
_GLTF_TYPE_SHAPE = {
    "SCALAR": (1, 1),
    "VEC2": (1, 2),
    "VEC3": (1, 3),
    "VEC4": (1, 4),
    "MAT2": (2, 2),
    "MAT3": (3, 3),
    "MAT4": (4, 4),
}


def _gltf_element_bytes(accessor: dict[str, Any]) -> int:
    component_bytes = _GLTF_COMPONENT_BYTES.get(accessor.get("componentType"))
    shape = _GLTF_TYPE_SHAPE.get(accessor.get("type"))
    if component_bytes is None or shape is None:
        raise ProviderError("conversion_failed", "GLB accessor layout is unsupported")
    columns, rows = shape
    column_bytes = component_bytes * rows
    column_stride = (column_bytes + 3) & ~3 if columns > 1 else column_bytes
    return columns * column_stride


def _parse_glb(path: str) -> tuple[dict[str, Any], bytes]:
    try:
        raw = Path(path).read_bytes()
        if len(raw) < 20 or len(raw) > MAX_GLB_BYTES or raw[:4] != b"glTF":
            raise ValueError
        if int.from_bytes(raw[4:8], "little") != 2 or int.from_bytes(raw[8:12], "little") != len(raw):
            raise ValueError
        chunks: dict[int, bytes] = {}
        offset = 12
        while offset < len(raw):
            if offset + 8 > len(raw):
                raise ValueError
            length = int.from_bytes(raw[offset : offset + 4], "little")
            kind = int.from_bytes(raw[offset + 4 : offset + 8], "little")
            offset += 8
            if length < 0 or offset + length > len(raw) or kind in chunks:
                raise ValueError
            chunks[kind] = raw[offset : offset + length]
            offset += length
        if offset != len(raw) or set(chunks) != {_GLB_JSON_CHUNK, _GLB_BIN_CHUNK}:
            raise ValueError
        document = json.loads(chunks[_GLB_JSON_CHUNK].rstrip(b" \t\r\n\0"))
        if not isinstance(document, dict):
            raise ValueError
        return document, chunks[_GLB_BIN_CHUNK]
    except ProviderError:
        raise
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        raise ProviderError("conversion_failed", "GLB normalization failed") from None


def _write_glb(path: str, document: dict[str, Any], binary: bytes) -> None:
    json_bytes = json.dumps(document, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    json_bytes += b" " * ((-len(json_bytes)) % 4)
    binary_chunk = binary + b"\0" * ((-len(binary)) % 4)
    total = 12 + 8 + len(json_bytes) + 8 + len(binary_chunk)
    if total > MAX_GLB_BYTES:
        raise ProviderError("conversion_failed", "normalized GLB exceeds limit")
    output = (
        b"glTF"
        + (2).to_bytes(4, "little")
        + total.to_bytes(4, "little")
        + len(json_bytes).to_bytes(4, "little")
        + _GLB_JSON_CHUNK.to_bytes(4, "little")
        + json_bytes
        + len(binary_chunk).to_bytes(4, "little")
        + _GLB_BIN_CHUNK.to_bytes(4, "little")
        + binary_chunk
    )
    original = _lstat(path)
    if stat.S_ISLNK(original.st_mode) or not stat.S_ISREG(original.st_mode):
        raise ProviderError("conversion_failed", "GLB source is not a regular file")
    temporary = f"{path}.normalize-{uuid.uuid4().hex}"
    fd = parent_fd = None
    try:
        fd, parent_fd, _leaf = _open_quarantine_file(temporary, os.path.dirname(os.path.abspath(path)))
        with os.fdopen(fd, "wb", closefd=True) as handle:
            fd = None
            handle.write(output)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except ProviderError:
        raise
    except OSError:
        raise ProviderError("conversion_failed", "GLB normalization failed") from None
    finally:
        if fd is not None:
            os.close(fd)
        if parent_fd is not None:
            os.close(parent_fd)
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def normalize_glb_for_engine(path: str) -> bool:
    """Rewrite interleaved accessors into Engine-compatible dense views."""

    document, binary_chunk = _parse_glb(path)
    buffers = document.get("buffers")
    accessors = document.get("accessors")
    views = document.get("bufferViews")
    if not isinstance(buffers, list) or len(buffers) != 1 or not isinstance(buffers[0], dict):
        raise ProviderError("conversion_failed", "GLB buffer layout is unsupported")
    if not isinstance(accessors, list) or not isinstance(views, list):
        raise ProviderError("conversion_failed", "GLB accessor layout is unsupported")
    declared_bytes = buffers[0].get("byteLength")
    if not isinstance(declared_bytes, int) or declared_bytes < 0 or declared_bytes > len(binary_chunk):
        raise ProviderError("conversion_failed", "GLB buffer length is invalid")
    binary = bytearray(binary_chunk[:declared_bytes])
    changed = False
    for accessor in accessors:
        if not isinstance(accessor, dict) or "sparse" in accessor:
            raise ProviderError("conversion_failed", "GLB accessor layout is unsupported")
        view_index = accessor.get("bufferView")
        if not isinstance(view_index, int) or not 0 <= view_index < len(views):
            raise ProviderError("conversion_failed", "GLB accessor view is invalid")
        view = views[view_index]
        if not isinstance(view, dict) or view.get("buffer", 0) != 0:
            raise ProviderError("conversion_failed", "GLB accessor buffer is unsupported")
        stride = view.get("byteStride")
        if stride is None:
            continue
        element_bytes = _gltf_element_bytes(accessor)
        count = accessor.get("count")
        view_offset = view.get("byteOffset", 0)
        accessor_offset = accessor.get("byteOffset", 0)
        view_length = view.get("byteLength")
        if (
            not isinstance(stride, int)
            or stride < element_bytes
            or stride > 252
            or not isinstance(count, int)
            or count < 1
            or not isinstance(view_offset, int)
            or view_offset < 0
            or not isinstance(accessor_offset, int)
            or accessor_offset < 0
            or not isinstance(view_length, int)
            or view_length < 1
        ):
            raise ProviderError("conversion_failed", "GLB interleaved accessor is invalid")
        source_start = view_offset + accessor_offset
        source_end = source_start + (count - 1) * stride + element_bytes
        if source_end > view_offset + view_length or source_end > declared_bytes:
            raise ProviderError("conversion_failed", "GLB interleaved accessor exceeds its view")
        binary.extend(b"\0" * ((-len(binary)) % 4))
        target_offset = len(binary)
        for index in range(count):
            start = source_start + index * stride
            binary.extend(binary_chunk[start : start + element_bytes])
        new_view: dict[str, Any] = {
            "buffer": 0,
            "byteOffset": target_offset,
            "byteLength": count * element_bytes,
        }
        if "target" in view:
            new_view["target"] = view["target"]
        views.append(new_view)
        accessor["bufferView"] = len(views) - 1
        accessor.pop("byteOffset", None)
        changed = True
    if not changed:
        return False
    buffers[0]["byteLength"] = len(binary)
    _write_glb(path, document, bytes(binary))
    _validate_glb_header(path)
    return True


def normalize_package_glbs(asset_dir: str, *, deadline_at: float | None = None) -> None:
    for root, dirs, files in os.walk(asset_dir, topdown=True, followlinks=False):
        if deadline_at is not None and time.monotonic() >= deadline_at:
            raise DeadlineExceeded()
        for directory in list(dirs):
            if os.path.islink(os.path.join(root, directory)):
                raise ProviderError("conversion_failed", "GLB package contains a symlink")
        for filename in sorted(files):
            if filename.lower().endswith(".glb"):
                normalize_glb_for_engine(os.path.join(root, filename))


def _classify_role(path: str, *, primary: bool = False) -> str:
    lower = path.lower()
    if primary:
        return "primary-model"
    if lower.endswith(".glb"):
        return "animation" if ("anim" in Path(path).stem.lower() or Path(path).stem.lower().endswith("_rig")) else "auxiliary-model"
    if Path(path).suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".ktx2", ".dds"}:
        return "texture"
    return "metadata"


def _classify_extracted_files(extract_dir: str) -> dict[str, Any]:
    """Preserve the historical classifier used by older raw callers."""

    files: dict[str, Any] = {"textures": [], "static_mesh": None, "rig": None, "animations": []}
    for entry in sorted(os.listdir(extract_dir)):
        if entry in _IGNORED_FILES:
            continue
        full = os.path.join(extract_dir, entry)
        if not os.path.isfile(full):
            continue
        external = _display_path(full)
        name_lower = entry.lower()
        stem, ext = os.path.splitext(name_lower)
        if entry.upper().startswith("T_"):
            files["textures"].append(external)
        elif ext in MODEL_EXTS:
            if entry.upper().startswith("SM_"):
                files["static_mesh"] = external
            elif stem.endswith("_rig"):
                files["rig"] = external
            else:
                files["animations"].append(external)
    return {key: value for key, value in files.items() if value}


def _build_manifest(
    asset_dir: str,
    *,
    deadline_at: float | None = None,
) -> tuple[list[dict[str, Any]], str, int, str]:
    paths: list[str] = []
    for root, dirs, files in os.walk(asset_dir, topdown=True, followlinks=False):
        if deadline_at is not None and time.monotonic() >= deadline_at:
            raise DeadlineExceeded()
        for directory in list(dirs):
            full = os.path.join(root, directory)
            st = _lstat(full)
            if stat.S_ISLNK(st.st_mode):
                raise ProviderError("archive_rejected", "quarantine symlink is not allowed")
        for filename in files:
            full = os.path.join(root, filename)
            st = _lstat(full)
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
                raise ProviderError("archive_rejected", "quarantine file type is not allowed")
            relative = os.path.relpath(full, asset_dir).replace(os.sep, "/")
            _safe_relative_member(relative)
            size = st.st_size
            if size <= 0 or size > MAX_FILE_BYTES:
                raise ProviderError("archive_rejected", "asset file size exceeds limit")
            paths.append(relative)
    if not paths:
        raise ProviderError("conversion_failed", "asset contains no files")
    paths.sort(key=lambda value: value.encode("utf-8"))
    model_paths = [path for path in paths if path.lower().endswith(".glb")]
    if not model_paths:
        raise ProviderError("conversion_failed", "asset contains no GLB model")
    primary_candidates = [path for path in model_paths if Path(path).name.upper().startswith("SM_")]
    primary = (primary_candidates or model_paths)[0]
    manifest: list[dict[str, Any]] = []
    total = 0
    row_digest = hashlib.sha256()
    for path in paths:
        full = os.path.join(asset_dir, *path.split("/"))
        st = _lstat(full)
        file_digest = hashlib.sha256()
        with open(full, "rb") as handle:
            while True:
                if deadline_at is not None and time.monotonic() >= deadline_at:
                    raise DeadlineExceeded()
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                file_digest.update(chunk)
        digest = file_digest.hexdigest()
        bytes_count = st.st_size
        role = _classify_role(path, primary=path == primary)
        manifest.append({"path": path, "role": role, "bytes": bytes_count, "sha256": digest})
        total += bytes_count
        row_digest.update(path.encode("utf-8"))
        row_digest.update(b"\0")
        row_digest.update(str(bytes_count).encode("ascii"))
        row_digest.update(b"\0")
        row_digest.update(digest.encode("ascii"))
        row_digest.update(b"\n")
    if total <= 0 or total > MAX_GLB_BYTES:
        raise ProviderError("archive_rejected", "asset size exceeds limit")
    for path in model_paths:
        _validate_glb_header(os.path.join(asset_dir, *path.split("/")))
    return manifest, primary, total, row_digest.hexdigest()


def _rebase_manifest_to_output(
    manifest: list[dict[str, Any]],
    primary: str,
    asset_dir: str,
    output_dir: str,
) -> tuple[list[dict[str, Any]], str, str]:
    """Bind declared files to the caller-owned transaction root."""

    relative_dir = os.path.relpath(asset_dir, output_dir).replace(os.sep, "/")
    prefix = _safe_relative_member(relative_dir, directory=True)
    rebased: list[dict[str, Any]] = []
    row_digest = hashlib.sha256()
    for entry in manifest:
        path = _safe_relative_member(f"{prefix}/{entry['path']}")
        row = {**entry, "path": path}
        rebased.append(row)
        row_digest.update(path.encode("utf-8"))
        row_digest.update(b"\0")
        row_digest.update(str(row["bytes"]).encode("ascii"))
        row_digest.update(b"\0")
        row_digest.update(str(row["sha256"]).encode("ascii"))
        row_digest.update(b"\n")
    return rebased, _safe_relative_member(f"{prefix}/{primary}"), row_digest.hexdigest()


async def _download_and_extract(
    session: Any,
    item: dict[str, Any],
    output_dir: str,
    output_format: str = DEFAULT_OUTPUT_FORMAT,
    *,
    deadline: Deadline | None = None,
    query_index: int = 0,
    authorized_origins: Iterable[str] | None = None,
    origin_set_digest: str | None = None,
) -> dict[str, Any]:
    content = str(item["content"])
    asset = item["asset"]
    provider_id = str(item["providerAssetId"])
    url = str(item["download_url"])
    download_method = str(asset.get("_download_method", "get"))
    origins = tuple(authorized_origins or load_authorized_origins()[0])
    if origin_set_digest is None:
        compact_origins = json.dumps(list(sorted(origins)), ensure_ascii=True, separators=(",", ":"))
        origin_set_digest = hashlib.sha256(compact_origins.encode("utf-8")).hexdigest()
    asset_dir = _make_asset_dir(output_dir, query_index, provider_id)
    keep = False
    try:
        if deadline is not None:
            deadline.ensure()
        ext = _guess_ext(asset, url)
        if ext == "zip":
            archive_path = os.path.join(asset_dir, ".asset-package.zip")
            await download_file(session, url, archive_path, authorized_origins=origins, deadline=deadline)
            await _await_blocking(
                _safe_extract_zip,
                archive_path,
                asset_dir,
                deadline=deadline,
                timeout=DOWNLOAD_ITEM_TIMEOUT_SECONDS,
                timeout_code="download_timeout",
                timeout_message="asset extraction timed out",
                operation_kwargs={
                    "deadline_at": time.monotonic() + deadline.remaining if deadline else None
                },
            )
            os.unlink(archive_path)
            if output_format == "glb":
                errors = await _await_blocking(
                    convert_package_dir,
                    asset_dir,
                    "glb",
                    deadline=deadline,
                    timeout=DOWNLOAD_ITEM_TIMEOUT_SECONDS,
                    timeout_code="conversion_failed",
                    timeout_message="GLB conversion timed out",
                    operation_kwargs={
                        "deadline_at": time.monotonic() + deadline.remaining if deadline else None
                    },
                )
                if errors:
                    raise ProviderError("conversion_failed", "GLB conversion failed")
        else:
            filename = _asset_name(asset)
            suffix = ext if re.fullmatch(r"[a-z0-9]{1,12}", ext) else "bin"
            source_path = os.path.join(asset_dir, f"{filename}.{suffix}")
            if download_method == "catalog-post":
                await download_catalog_asset(
                    session,
                    url,
                    provider_id,
                    source_path,
                    authorized_origins=origins,
                    deadline=deadline,
                )
            else:
                await download_file(session, url, source_path, authorized_origins=origins, deadline=deadline)
            if output_format == "glb":
                if suffix == "fbx":
                    target = os.path.join(asset_dir, f"{filename}.glb")
                    try:
                        await asyncio.wait_for(
                            asyncio.to_thread(convert_fbx_to_glb, source_path, target),
                            deadline.timeout(DOWNLOAD_ITEM_TIMEOUT_SECONDS) if deadline else DOWNLOAD_ITEM_TIMEOUT_SECONDS,
                        )
                    except ProviderError:
                        raise
                    except (asyncio.TimeoutError, TimeoutError):
                        raise ProviderError("conversion_failed", "GLB conversion failed") from None
                    os.unlink(source_path)
                elif suffix != "glb":
                    raise ProviderError("conversion_failed", "GLB conversion failed")
        if deadline is not None:
            deadline.ensure()
        if output_format == "glb":
            await _await_blocking(
                normalize_package_glbs,
                asset_dir,
                deadline=deadline,
                timeout=DOWNLOAD_ITEM_TIMEOUT_SECONDS,
                timeout_code="conversion_failed",
                timeout_message="GLB normalization timed out",
                operation_kwargs={
                    "deadline_at": time.monotonic() + deadline.remaining if deadline else None
                },
            )
        if output_format == "fbx":
            # Historical raw callers receive the original shape.  This branch
            # intentionally does not feed FBX bytes into the GLB-only checked
            # schema; Game Plugin always selects the canonical glb branch.
            final_path = asset_dir
            if ext != "zip":
                final_path = os.path.join(asset_dir, f"{_asset_name(asset)}.{ext}")
            legacy = {
                "content": content,
                "downloaded_to": _display_path(final_path),
                "format": "fbx",
            }
            if ext == "zip":
                legacy["files"] = _classify_extracted_files(asset_dir)
            keep = True
            return legacy
        manifest, primary, bytes_count, _asset_digest = await _await_blocking(
            _build_manifest,
            asset_dir,
            deadline=deadline,
            timeout=DOWNLOAD_ITEM_TIMEOUT_SECONDS,
            timeout_code="digest_failed",
            timeout_message="asset digest timed out",
            operation_kwargs={
                "deadline_at": time.monotonic() + deadline.remaining if deadline else None
            },
        )
        manifest, primary, digest = _rebase_manifest_to_output(
            manifest,
            primary,
            asset_dir,
            output_dir,
        )
        result = {
            "status": "ok",
            "queryIndex": query_index,
            "query": content,
            "provider": PROVIDER_NAME,
            "providerAssetId": provider_id,
            "assetName": _asset_name(asset),
            "deliveredFormat": "glb",
            "sha256": digest,
            "bytes": bytes_count,
            "primaryModel": primary,
            "manifest": manifest,
            "originSetDigest": origin_set_digest,
            # Display-only: no consumer is allowed to join this value.
            "downloaded_to": _display_path(asset_dir),
        }
        keep = True
        _log_event("asset_ok", query_index=query_index, asset_id=provider_id, bytes_count=bytes_count, digest=digest)
        return result
    except asyncio.CancelledError:
        raise
    except ProviderError as exc:
        _log_event(exc.code, query_index=query_index, asset_id=provider_id)
        raise
    except Exception:
        _log_event("internal_error", query_index=query_index, asset_id=provider_id)
        raise ProviderError("internal_error", "asset retrieval failed", retryable=True) from None
    finally:
        if not keep:
            await _bounded_cleanup(asset_dir)


# ---------------------------------------------------------------------------
# Checked result envelope and batch deadline orchestration
# ---------------------------------------------------------------------------


def _safe_query_for_result(value: object) -> str:
    content = _query_content(value)
    if not content:
        return "unknown"
    return content[:200]


def _error_row(index: int, query: object, code: str, message: str | None = None, *, retryable: bool | None = None) -> dict[str, Any]:
    if code not in ERROR_CODES:
        code = "internal_error"
    return {
        "status": "error",
        "queryIndex": index,
        "query": _safe_query_for_result(query),
        "code": code,
        "retryable": code in RETRYABLE_CODES if retryable is None else bool(retryable),
        "message": _redact_message(message or code.replace("_", " ")),
    }


def _validate_result_shape(payload: dict[str, Any]) -> None:
    base_fields = {"schemaVersion", "total", "succeeded", "failed", "results"}
    if not isinstance(payload, dict) or not base_fields.issubset(payload) or set(payload) - base_fields - {"receipt"} or payload.get("schemaVersion") != SCHEMA_VERSION:
        raise ValueError("schema version")
    results = payload.get("results")
    total = payload.get("total")
    succeeded = payload.get("succeeded")
    failed = payload.get("failed")
    if (
        not isinstance(results, list)
        or type(total) is not int
        or not 1 <= total <= MAX_QUERIES
        or len(results) != total
        or type(succeeded) is not int
        or type(failed) is not int
        or not 0 <= succeeded <= MAX_QUERIES
        or not 0 <= failed <= MAX_QUERIES
    ):
        raise ValueError("result count")
    if succeeded + failed != total:
        raise ValueError("result totals")
    receipt = payload.get("receipt")
    if receipt is not None:
        if (
            not isinstance(receipt, dict)
            or set(receipt) != {"schemaVersion", "provider", "providerCommit", "originSetDigest"}
            or receipt.get("schemaVersion") != RECEIPT_SCHEMA_VERSION
            or receipt.get("provider") != PROVIDER_NAME
            or not isinstance(receipt.get("providerCommit"), str)
            or not re.fullmatch(r"[0-9a-f]{40}", receipt["providerCommit"])
            or not isinstance(receipt.get("originSetDigest"), str)
            or not _HEX64_RE.fullmatch(receipt["originSetDigest"])
        ):
            raise ValueError("receipt")
    if succeeded > 0 and receipt is None:
        raise ValueError("receipt")
    indices: list[int] = []
    for row in results:
        if not isinstance(row, dict) or type(row.get("queryIndex")) is not int:
            raise ValueError("result row")
        index = row["queryIndex"]
        if index < 0 or index >= total or index in indices:
            raise ValueError("query index")
        indices.append(index)
        query = row.get("query")
        if not isinstance(query, str) or not 1 <= len(query) <= 200:
            raise ValueError("query")
        if row.get("status") == "ok":
            required = {"status", "queryIndex", "query", "provider", "providerAssetId", "assetName", "deliveredFormat", "sha256", "bytes", "primaryModel", "manifest", "originSetDigest"}
            if set(row) - required - {"downloaded_to"} or not required.issubset(row):
                raise ValueError("success fields")
            if row["provider"] != PROVIDER_NAME or row["deliveredFormat"] != "glb":
                raise ValueError("success identity")
            if not isinstance(row["providerAssetId"], str) or not _SAFE_ID_RE.fullmatch(row["providerAssetId"]) or row["providerAssetId"] in {".", ".."}:
                raise ValueError("asset id")
            if not isinstance(row["assetName"], str) or not 1 <= len(row["assetName"]) <= 128:
                raise ValueError("asset name")
            if not isinstance(row["sha256"], str) or not _HEX64_RE.fullmatch(row["sha256"]):
                raise ValueError("digest")
            if receipt is None or row["originSetDigest"] != receipt["originSetDigest"]:
                raise ValueError("origin digest")
            if type(row["bytes"]) is not int or not 1 <= row["bytes"] <= MAX_GLB_BYTES:
                raise ValueError("bytes")
            manifest = row["manifest"]
            if not isinstance(manifest, list) or not 1 <= len(manifest) <= MAX_ARCHIVE_MEMBERS:
                raise ValueError("manifest")
            paths: list[str] = []
            primary_count = 0
            total_bytes = 0
            for entry in manifest:
                if not isinstance(entry, dict) or set(entry) != {"path", "role", "bytes", "sha256"}:
                    raise ValueError("manifest entry")
                path = entry["path"]
                if not isinstance(path, str):
                    raise ValueError("manifest path")
                _safe_relative_member(path)
                if len(path) > 512 or path in paths:
                    raise ValueError("manifest path")
                paths.append(path)
                if entry["role"] not in {"primary-model", "animation", "auxiliary-model", "texture", "metadata"}:
                    raise ValueError("manifest role")
                if type(entry["bytes"]) is not int or not 1 <= entry["bytes"] <= MAX_FILE_BYTES:
                    raise ValueError("manifest bytes")
                if not isinstance(entry["sha256"], str) or not _HEX64_RE.fullmatch(entry["sha256"]):
                    raise ValueError("manifest digest")
                total_bytes += entry["bytes"]
                if entry["role"] == "primary-model":
                    primary_count += 1
                    if not path.lower().endswith(".glb"):
                        raise ValueError("primary model")
            model_roles = {"primary-model", "animation", "auxiliary-model"}
            if any(entry["role"] in model_roles and not entry["path"].lower().endswith(".glb") for entry in manifest):
                raise ValueError("model format")
            primary_paths = [entry["path"] for entry in manifest if entry["role"] == "primary-model"]
            if paths != sorted(paths, key=lambda value: value.encode("utf-8")) or primary_count != 1 or total_bytes != row["bytes"] or row["primaryModel"] not in paths or primary_paths != [row["primaryModel"]]:
                raise ValueError("manifest ordering")
            digest = hashlib.sha256()
            for entry in manifest:
                digest.update(entry["path"].encode("utf-8"))
                digest.update(b"\0")
                digest.update(str(entry["bytes"]).encode("ascii"))
                digest.update(b"\0")
                digest.update(entry["sha256"].encode("ascii"))
                digest.update(b"\n")
            if digest.hexdigest() != row["sha256"]:
                raise ValueError("manifest digest")
            if not isinstance(row["primaryModel"], str) or not row["primaryModel"].lower().endswith(".glb"):
                raise ValueError("primary model")
            if "downloaded_to" in row:
                value = row["downloaded_to"]
                if not isinstance(value, str) or not 1 <= len(value) <= 512 or value.startswith("/") or "\\" in value or "//" in value or any(part in {"", ".", ".."} for part in value.split("/")):
                    raise ValueError("display path")
        elif row.get("status") == "error":
            if set(row) != {"status", "queryIndex", "query", "code", "retryable", "message"}:
                raise ValueError("error fields")
            if row["code"] not in ERROR_CODES or not isinstance(row["retryable"], bool) or not isinstance(row["message"], str) or not 1 <= len(row["message"]) <= 256:
                raise ValueError("error row")
        else:
            raise ValueError("status")
    if len(indices) != total:
        raise ValueError("missing query")


def validate_result(payload: dict[str, Any]) -> bool:
    """Public validator used by bundle verifier and focused tests."""

    try:
        _validate_result_shape(payload)
    except (TypeError, ValueError):
        return False
    return True


def _result_json(payload: dict[str, Any]) -> str:
    _validate_result_shape(payload)
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    if len(encoded.encode("utf-8")) > MAX_RESULT_BYTES:
        raise ProviderError("internal_error", "provider result exceeds limit", retryable=True)
    return encoded


async def _run_tasks_with_timeout(tasks: list[asyncio.Task], timeout: float) -> tuple[set[asyncio.Task], set[asyncio.Task]]:
    if not tasks:
        return set(), set()
    done, pending = await asyncio.wait(tasks, timeout=max(0.0, timeout))
    if pending:
        for task in pending:
            task.cancel()
        try:
            await asyncio.wait_for(asyncio.gather(*pending, return_exceptions=True), timeout=float(_contract_limits()["cleanup"]))
        except asyncio.TimeoutError:
            pass
    return done, pending


async def handle_batch_search_assets(args: dict[str, Any]) -> list[TextContent]:
    # Capture the whole-call budget before argument validation, quarantine
    # setup, semaphore acquisition or any network work.
    deadline = Deadline.start()
    queries = args.get("queries") if isinstance(args, dict) else None
    if not isinstance(queries, list) or not queries:
        return [TextContent(type="text", text=json.dumps({"error": "Missing required parameter: queries (must be a non-empty list)"}))]
    limits = _contract_limits()
    if len(queries) > int(limits["max_queries"]):
        return [TextContent(type="text", text=json.dumps({"error": "queries exceeds the maximum batch size"}))]
    output_format = _normalize_output_format(args.get("output_format"))
    # ``fbx`` remains a raw compatibility path.  A canonical caller passes
    # glb, and therefore obtains the strict result schema.
    try:
        output_dir = _resolve_output_dir(args.get("output_dir"))
        authorized_origins, origin_digest = load_authorized_origins()
    except ProviderError as exc:
        rows = [_error_row(i, query, exc.code, exc.message) for i, query in enumerate(queries)]
        payload = {"schemaVersion": SCHEMA_VERSION, "total": len(rows), "succeeded": 0, "failed": len(rows), "results": rows}
        return [TextContent(type="text", text=_result_json(payload))] if output_format == "glb" else [TextContent(type="text", text=json.dumps({"error": exc.message}))]

    response_list: list[dict[str, Any] | None] = [None] * len(queries)
    search_sem = asyncio.Semaphore(MAX_CONCURRENT_SEARCHES)
    download_sem = asyncio.Semaphore(MAX_CONCURRENT_DOWNLOADS)
    async with _client_session() as session:
        async def search_task(index: int, query: object) -> dict[str, Any]:
            try:
                async with search_sem:
                    timeout = deadline.timeout(float(limits["search_item"]))
                    return await asyncio.wait_for(_search_one(session, query, deadline=deadline), timeout=timeout)
            except asyncio.TimeoutError:
                raise ProviderError("search_timeout", "search timed out", retryable=True) from None
            except DeadlineExceeded:
                raise DeadlineExceeded("batch_timeout")

        search_tasks = [asyncio.create_task(search_task(i, query)) for i, query in enumerate(queries)]
        search_started = asyncio.get_running_loop().time()
        search_wait_timeout = min(float(limits["search_batch"]), deadline.remaining)
        _done, pending = await _run_tasks_with_timeout(search_tasks, search_wait_timeout)
        search_window_expired = asyncio.get_running_loop().time() - search_started >= search_wait_timeout
        pending_set = set(pending)
        for index, task in enumerate(search_tasks):
            if task in pending_set:
                response_list[index] = _error_row(index, queries[index], "batch_timeout", retryable=True)
                continue
            try:
                response_list[index] = task.result()
            except ProviderError as exc:
                code = "batch_timeout" if isinstance(exc, DeadlineExceeded) or (search_window_expired and exc.code == "search_timeout") else exc.code
                response_list[index] = _error_row(index, queries[index], code, exc.message)
            except Exception:
                response_list[index] = _error_row(index, queries[index], "internal_error", retryable=True)

        async def download_task(index: int, item: dict[str, Any]) -> dict[str, Any]:
            try:
                async with download_sem:
                    timeout = deadline.timeout(float(limits["download_item"]))
                    return await asyncio.wait_for(
                        _download_and_extract(
                            session,
                            item,
                            output_dir,
                            output_format,
                            deadline=deadline,
                            query_index=index,
                            authorized_origins=authorized_origins,
                            origin_set_digest=origin_digest,
                        ),
                        timeout=timeout,
                    )
            except asyncio.TimeoutError:
                raise ProviderError("download_timeout", "download timed out", retryable=True)
            except DeadlineExceeded:
                raise DeadlineExceeded("batch_timeout")

        download_tasks: list[asyncio.Task] = []
        download_indices: list[int] = []
        for index, item in enumerate(response_list):
            if isinstance(item, dict) and "asset" in item and "download_url" in item:
                download_indices.append(index)
                download_tasks.append(asyncio.create_task(download_task(index, item)))
        _done, pending = await _run_tasks_with_timeout(download_tasks, deadline.remaining)
        pending_set = set(pending)
        for index, task in zip(download_indices, download_tasks):
            if task in pending_set:
                response_list[index] = _error_row(index, queries[index], "batch_timeout", retryable=True)
                continue
            try:
                response_list[index] = task.result()
            except ProviderError as exc:
                code = "batch_timeout" if isinstance(exc, DeadlineExceeded) else exc.code
                response_list[index] = _error_row(index, queries[index], code, exc.message)
            except Exception:
                response_list[index] = _error_row(index, queries[index], "internal_error", retryable=True)

    rows = [row for row in response_list if isinstance(row, dict)]
    while len(rows) < len(queries):
        index = len(rows)
        rows.append(_error_row(index, queries[index], "batch_timeout", retryable=True))
    rows.sort(key=lambda row: row["queryIndex"])
    if output_format == "fbx":
        legacy_rows = []
        for row in rows:
            if row.get("status") == "ok" or "downloaded_to" in row:
                legacy_rows.append({"content": row.get("query", ""), "downloaded_to": row.get("downloaded_to", ""), "format": "fbx"})
            else:
                legacy_rows.append({"content": row.get("query", ""), "error": row.get("message", "provider error")})
        succeeded = sum(1 for row in rows if row.get("status") == "ok" or "downloaded_to" in row)
        return [TextContent(type="text", text=json.dumps({"total": len(rows), "succeeded": succeeded, "failed": len(rows) - succeeded, "results": legacy_rows}, ensure_ascii=False))]

    successes = sum(1 for row in rows if row.get("status") == "ok")
    payload = {
        "schemaVersion": SCHEMA_VERSION,
        "total": len(rows),
        "succeeded": successes,
        "failed": len(rows) - successes,
        "results": rows,
        "receipt": _origin_receipt(origin_digest),
    }
    try:
        encoded = _result_json(payload)
    except ProviderError:
        for row in reversed(rows):
            if row.get("status") == "ok":
                query_index = int(row.get("queryIndex", 0))
                row.clear()
                row.update(_error_row(query_index, "result", "internal_error", "provider result exceeds limit", retryable=True))
                payload["succeeded"] -= 1
                payload["failed"] += 1
                try:
                    encoded = _result_json(payload)
                    break
                except ProviderError:
                    continue
        else:
            encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))[:MAX_RESULT_BYTES]
    return [TextContent(type="text", text=encoded)]


def _normalize_output_format(raw: str | None) -> str:
    fmt = raw.strip().lower().lstrip(".") if isinstance(raw, str) else ""
    return fmt if fmt in SUPPORTED_OUTPUT_FORMATS else DEFAULT_OUTPUT_FORMAT


class _ClientSessionContext:
    def __init__(self) -> None:
        self.session: Any = None

    async def __aenter__(self) -> Any:
        if aiohttp is None:
            return _UnavailableSession()
        tls = ssl.create_default_context(cafile=certifi.where() if certifi is not None else None)
        connector = aiohttp.TCPConnector(ssl=tls)
        self.session = aiohttp.ClientSession(connector=connector)
        return await self.session.__aenter__()

    async def __aexit__(self, *args: Any) -> None:
        if self.session is not None:
            await self.session.__aexit__(*args)


class _UnavailableSession:
    async def __aenter__(self) -> "_UnavailableSession":
        return self

    async def __aexit__(self, *_args: Any) -> None:
        return None


def _client_session() -> _ClientSessionContext:
    return _ClientSessionContext()


# ---------------------------------------------------------------------------
# MCP transport
# ---------------------------------------------------------------------------


server = Server("asset3d-search")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="search_asset",
            description=(
                "Batch search and download game assets from the curated asset library. "
                "Use one call with concrete English queries. Game Plugin callers request "
                "output_format=glb; downloaded_to is display-only."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "queries": {"type": "array", "minItems": 1, "maxItems": MAX_QUERIES, "items": {"type": "string"}},
                    "output_format": {"type": "string", "enum": ["glb", "fbx"], "default": "fbx"},
                    "output_dir": {"type": "string"},
                },
                "required": ["queries"],
            },
        )
    ]


def _to_call_tool_result(content: list[TextContent], default_is_error: bool = False) -> CallToolResult:
    is_error = default_is_error
    if content:
        text = getattr(content[0], "text", "") or ""
        try:
            payload = json.loads(text)
            if isinstance(payload, dict) and payload.get("error"):
                is_error = True
        except (TypeError, ValueError):
            if str(text).lower().startswith(("error:", "failed:", "unknown tool:")):
                is_error = True
    return CallToolResult(content=content, isError=is_error)


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
    if name == "search_asset":
        return _to_call_tool_result(await handle_batch_search_assets(arguments))
    return CallToolResult(content=[TextContent(type="text", text="Unknown tool")], isError=True)


async def run_stdio() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def check_dependencies() -> list[str]:
    missing: list[str] = []
    if aiohttp is None:
        missing.append("aiohttp")
    if certifi is None:
        missing.append("certifi")
    try:
        __import__("mcp")
    except ImportError:
        missing.append("mcp")
    return missing


def main() -> None:
    missing = check_dependencies()
    if missing:
        print("asset3d-search provider dependencies are unavailable", file=sys.stderr)
        raise SystemExit(1)
    if sys.argv[1:] == ["--check-aw-access"]:
        result = asyncio.run(check_aw_access())
        print(json.dumps(result, ensure_ascii=True, separators=(",", ":")))
        raise SystemExit(0 if result.get("ok") is True else 1)
    if len(sys.argv) > 1:
        print("asset3d-search provider received an unsupported argument", file=sys.stderr)
        raise SystemExit(2)
    if os.environ.get("MCP_TRANSPORT", "stdio") == "http":
        from utils import run_http_server

        run_http_server(server, port=int(os.environ.get("MCP_PORT", "3108")), service_name="asset3d-search")
        return
    asyncio.run(run_stdio())


if __name__ == "__main__":
    main()
