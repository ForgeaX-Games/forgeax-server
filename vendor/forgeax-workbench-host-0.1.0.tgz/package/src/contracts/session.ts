import { z } from "zod"

export const WorkbenchSessionContextSchema = z.object({
  extensionId: z.string().min(1),
  runtimeId: z.string().min(1),
  gameId: z.string().min(1),
  locale: z.string().min(1),
  theme: z.enum(["light", "dark"]),
  endpoints: z.object({
    toolCall: z.string().min(1),
    gamePackage: z.string().min(1),
    extensionApi: z.string().min(1),
    gameVersions: z.string().min(1).optional(),
    gameComponents: z.string().min(1).optional(),
  }),
  capabilities: z.array(z.string().min(1)),
})

export type WorkbenchSessionContext = z.infer<typeof WorkbenchSessionContextSchema>
