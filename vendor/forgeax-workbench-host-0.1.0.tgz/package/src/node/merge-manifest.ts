import { z } from "zod"

const RelativeEntrySchema = z.string().min(1)

const LocalizedTextSchema = z.union([
  z.string().min(1),
  z
    .object({
      zh: z.string().min(1).optional(),
      en: z.string().min(1).optional(),
      ja: z.string().min(1).optional(),
    })
    .strict()
    .refine((value) => value.zh !== undefined || value.en !== undefined || value.ja !== undefined),
])

type LocalizedText = z.infer<typeof LocalizedTextSchema>

const PaneSchema = z
  .object({
    minWidth: z.number().finite().nonnegative().optional(),
    minHeight: z.number().finite().nonnegative().optional(),
    width: z.number().finite().nonnegative().optional(),
    scrollable: z.boolean().optional(),
  })
  .strict()

const PanesSchema = z
  .object({
    left: PaneSchema.optional(),
    center: PaneSchema.optional(),
  })
  .strict()

const InternalToolSchema = z
  .object({
    id: z.string().min(1),
    title: z.string().min(1).optional(),
    description: z.string().min(1).optional(),
    inputSchema: z.string().min(1),
    outputSchema: z.string().min(1).optional(),
    permissions: z.array(z.string().min(1)).optional(),
    exposedToAI: z.boolean().optional(),
    requireConfirm: z.enum(["always", "destructive", "never"]).optional(),
    confirmMessage: z.string().min(1).optional(),
  })
  .strict()

const InternalEntrySchema = z
  .object({
    frontend: RelativeEntrySchema,
    backend: RelativeEntrySchema,
  })
  .strict()

export const ExtensionManifestSchema = z
  .object({
    kind: z.literal("workbench"),
    id: z.string().min(1),
    version: z.string().min(1),
    displayName: z.string().min(1),
    icon: z.string().min(1).optional(),
    entry: InternalEntrySchema,
    provides: z
      .object({
        workbench: z
          .object({
            surface: z.string().min(1).optional(),
            panes: PanesSchema,
          })
          .strict(),
      })
      .strict(),
    permissions: z.array(z.string().min(1)),
    requestedEnv: z.array(z.string().min(1)),
    tools: z.array(InternalToolSchema),
  })
  .strict()

export type ExtensionManifest = z.infer<typeof ExtensionManifestSchema>

const StandaloneEntrySchema = z
  .object({
    start: z.string().min(1).optional(),
    port: z.number().int().positive().max(65_535).optional(),
    readyProbe: z.string().min(1).optional(),
    dev: z
      .object({
        watch: z.boolean().optional(),
        hmr: z.boolean().optional(),
      })
      .strict()
      .optional(),
    embeddedAlso: z.boolean().optional(),
    devOnly: z.boolean().optional(),
  })
  .strict()

const RawEntrySchema = z
  .object({
    frontend: RelativeEntrySchema,
    backend: RelativeEntrySchema,
    standalone: StandaloneEntrySchema.optional(),
  })
  .strict()

const FormalToolSchema = z
  .object({
    id: z.string().min(1),
    args: z.string().min(1).optional(),
    returns: z.string().min(1).optional(),
    exposedToAI: z.boolean().optional(),
    requireConfirm: z.enum(["always", "destructive", "never"]).optional(),
    confirmMessage: LocalizedTextSchema.optional(),
    description: LocalizedTextSchema.optional(),
  })
  .strict()

const SkillEntrySchema = z
  .object({
    id: z.string().min(1),
    entry: z.string().min(1).optional(),
    trigger: z.string().min(1).optional(),
    triggers: z.array(z.string().min(1)).optional(),
    requiresTools: z.array(z.string().min(1)).optional(),
    permissions: z.array(z.string().min(1)).optional(),
    timeoutMs: z.number().int().positive().optional(),
    displayName: LocalizedTextSchema.optional(),
    description: LocalizedTextSchema.optional(),
  })
  .strict()

const EventSchema = z
  .object({
    name: z.string().min(1),
    payload: z.unknown().optional(),
  })
  .strict()

const SurfaceSchema = z
  .object({
    id: z.string().min(1),
    schema: z.string().min(1).optional(),
    actions: z
      .array(
        z
          .object({
            id: z.string().min(1),
            exposedToAI: z.boolean().optional(),
            permission: z.string().min(1).optional(),
            requireConfirm: z.enum(["always", "destructive", "never"]).optional(),
          })
          .strict(),
      )
      .optional(),
  })
  .strict()

const WorkbenchContributionSchema = z
  .object({
    id: z.string().min(1).optional(),
    lens: z.string().min(1).optional(),
    icon: z.string().min(1).optional(),
    position: z.number().finite().optional(),
    panelSize: z.enum(["sm", "md", "lg"]).optional(),
    surface: z.string().min(1).optional(),
    panes: PanesSchema,
    bus: z.object({ surfaceId: z.string().min(1) }).strict().optional(),
    matchProduces: z.array(z.string().min(1)).optional(),
    hidden: z.boolean().optional(),
    preferredAgent: z.string().min(1).optional(),
  })
  .strict()

const RawProvidesSchema = z
  .object({
    workbench: WorkbenchContributionSchema,
    skills: z.array(SkillEntrySchema).optional(),
    tools: z.array(FormalToolSchema).optional(),
    events: z.array(EventSchema).optional(),
    surfaces: z.array(SurfaceSchema).optional(),
  })
  .strict()

/**
 * The formal extension manifest grammar is an untrusted, compatibility-facing
 * input. It is strict at every declared boundary before being normalized into
 * the smaller internal host contract.
 */
export const RawExtensionManifestSchema = z
  .object({
    schemaVersion: z.literal(1).optional(),
    id: z.string().min(1),
    version: z.string().min(1),
    kind: z.literal("workbench"),
    displayName: LocalizedTextSchema,
    description: LocalizedTextSchema.optional(),
    author: z
      .object({
        name: z.string().min(1),
        email: z.string().min(1).optional(),
        url: z.string().min(1).optional(),
      })
      .strict()
      .optional(),
    icon: z.string().min(1).optional(),
    hidden: z.boolean().optional(),
    keywords: z.array(z.string().min(1)).optional(),
    dependencies: z
      .array(
        z
          .object({
            id: z.string().min(1),
            versionRange: z.string().min(1).optional(),
            optional: z.boolean().optional(),
          })
          .strict(),
      )
      .optional(),
    consumes: z
      .object({
        models: z
          .array(
            z
              .object({
                channel: z.string().min(1),
                role: z.string().min(1),
              })
              .strict(),
          )
          .optional(),
      })
      .strict()
      .optional(),
    entry: RawEntrySchema,
    provides: RawProvidesSchema,
    permissions: z.array(z.string().min(1)).optional(),
    requestedEnv: z.array(z.string().min(1)).optional(),
    hot: z.boolean().optional(),
    experimental: z.boolean().optional(),
    compatibleWith: z.record(z.string().min(1)).optional(),
    tools: z.array(InternalToolSchema).optional(),
  })
  .strict()

type RawExtensionManifest = z.infer<typeof RawExtensionManifestSchema>
type JsonRecord = Record<string, unknown>

function isRecord(value: unknown): value is JsonRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

function mergeValues(parent: unknown, child: unknown): unknown {
  if (isRecord(parent) && isRecord(child)) {
    const merged: JsonRecord = { ...parent }
    for (const [key, value] of Object.entries(child)) {
      merged[key] = key in merged ? mergeValues(merged[key], value) : value
    }
    return merged
  }

  return child
}

function localize(value: LocalizedText | undefined): string | undefined {
  if (value === undefined || typeof value === "string") {
    return value
  }
  return value.en ?? value.zh ?? value.ja
}

function normalizeFormalTool(tool: z.infer<typeof FormalToolSchema>) {
  return {
    id: tool.id,
    ...(tool.args === undefined ? {} : { inputSchema: tool.args }),
    ...(tool.returns === undefined ? {} : { outputSchema: tool.returns }),
    ...(tool.exposedToAI === undefined ? {} : { exposedToAI: tool.exposedToAI }),
    ...(tool.requireConfirm === undefined
      ? {}
      : { requireConfirm: tool.requireConfirm }),
    ...(localize(tool.confirmMessage) === undefined
      ? {}
      : { confirmMessage: localize(tool.confirmMessage) }),
    ...(localize(tool.description) === undefined
      ? {}
      : { description: localize(tool.description) }),
  }
}

/** Normalizes a strict formal manifest into the strict host-only shape. */
export function normalizeExtensionManifest(input: unknown): ExtensionManifest {
  const raw = RawExtensionManifestSchema.parse(input)
  const formalTools = raw.provides.tools?.map(normalizeFormalTool)
  return ExtensionManifestSchema.parse({
    kind: raw.kind,
    id: raw.id,
    version: raw.version,
    displayName: localize(raw.displayName),
    ...(raw.icon === undefined && raw.provides.workbench.icon === undefined
      ? {}
      : { icon: raw.icon ?? raw.provides.workbench.icon }),
    entry: {
      frontend: raw.entry.frontend,
      backend: raw.entry.backend,
    },
    provides: {
      workbench: {
        ...(raw.provides.workbench.surface === undefined
          ? {}
          : { surface: raw.provides.workbench.surface }),
        panes: raw.provides.workbench.panes,
      },
    },
    permissions: raw.permissions ?? [],
    requestedEnv: raw.requestedEnv ?? [],
    tools: formalTools ?? raw.tools ?? [],
  })
}

/**
 * Merges manifest layers from least to most specific. Objects merge
 * recursively; all other values, including arrays, are replaced by the child.
 */
export function mergeManifestLayers(layers: readonly unknown[]): ExtensionManifest {
  const merged = layers.reduce<unknown>((current, layer) => {
    if (!isRecord(layer)) {
      throw new TypeError("A manifest layer must be a JSON object")
    }
    return current === undefined ? layer : mergeValues(current, layer)
  }, undefined)

  return normalizeExtensionManifest(merged)
}
