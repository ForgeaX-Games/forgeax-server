import type {
  CurrentVersion,
  GameVersion,
  ScopedGameRoot,
  VersionAdapter,
  WorkspaceAdapter,
} from "../contracts/adapters.js"
import { WorkbenchError } from "../contracts/error.js"
import {
  gamePackageFromFiles,
  PACKAGE_FILES,
  type GamePackage,
  type PackageFile,
} from "./package-files.js"

export interface VersionServiceOptions {
  readonly workspace: WorkspaceAdapter
  readonly versioning: VersionAdapter
}

function invalidHistoricalPackageError(): WorkbenchError {
  return new WorkbenchError({
    code: "version_package_invalid",
    target: "version",
    message: "Version does not contain a complete valid game package",
    retryable: false,
  })
}

function parseHistoricalJson(bytes: Uint8Array | null): unknown {
  if (bytes === null) {
    throw invalidHistoricalPackageError()
  }
  try {
    return JSON.parse(new TextDecoder().decode(bytes)) as unknown
  } catch {
    throw invalidHistoricalPackageError()
  }
}

/** Routes all versioning calls through the injected adapter without checkout operations. */
export class VersionService {
  readonly #options: VersionServiceOptions

  constructor(options: VersionServiceOptions) {
    this.#options = options
  }

  async create(gameId: string, message: string): Promise<GameVersion> {
    return this.#withGameRoot(gameId, async ({ versions }) => {
      await versions.ensureRepository()
      return versions.createVersion(message)
    })
  }

  async current(gameId: string): Promise<CurrentVersion | null> {
    return this.#withGameRoot(gameId, ({ versions }) =>
      versions.currentVersion(),
    )
  }

  async list(gameId: string): Promise<GameVersion[]> {
    return this.#withGameRoot(gameId, ({ versions }) =>
      versions.listVersions(),
    )
  }

  async readAtTag(gameId: string, tag: string): Promise<GamePackage> {
    return this.#withGameRoot(gameId, async ({ versions }) => {
      const exists = (await versions.listVersions()).some(
        (version) => version.tag === tag,
      )
      if (!exists) {
        throw new WorkbenchError({
          code: "version_not_found",
          target: "version",
          message: "Version was not found",
          retryable: false,
        })
      }
      const entries = await Promise.all(
        PACKAGE_FILES.map(async (relativePath) => [
          relativePath,
          parseHistoricalJson(
            await versions.readFileAtVersion(tag, relativePath),
          ),
        ] as const),
      )
      return gamePackageFromFiles(new Map<PackageFile, unknown>(entries))
    })
  }

  async #withGameRoot<T>(
    gameId: string,
    operation: (scope: ScopedGameRoot) => Promise<T>,
  ): Promise<T> {
    let entered = false
    try {
      return await this.#options.workspace.withGameRoot(
        gameId,
        { create: false, versioning: this.#options.versioning },
        async (scope) => {
          entered = true
          return operation(scope)
        },
      )
    } catch (cause) {
      if (entered || cause instanceof WorkbenchError) {
        throw cause
      }
      throw new WorkbenchError({
        code: "workspace_not_found",
        target: "workspace",
        message: "Game workspace was not found",
        retryable: false,
      })
    }
  }
}
