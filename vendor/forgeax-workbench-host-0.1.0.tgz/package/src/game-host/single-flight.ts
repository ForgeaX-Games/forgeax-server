/** Coalesces concurrent operations for one logical resource key. */
export class SingleFlight {
  readonly #flights = new Map<string, Promise<unknown>>()

  run<T>(key: string, operation: () => Promise<T>): Promise<T> {
    const active = this.#flights.get(key)
    if (active) {
      return active as Promise<T>
    }

    const flight = Promise.resolve().then(operation)
    this.#flights.set(key, flight)
    void flight.then(
      () => this.#clear(key, flight),
      () => this.#clear(key, flight),
    )
    return flight
  }

  #clear(key: string, flight: Promise<unknown>): void {
    if (this.#flights.get(key) === flight) {
      this.#flights.delete(key)
    }
  }
}
